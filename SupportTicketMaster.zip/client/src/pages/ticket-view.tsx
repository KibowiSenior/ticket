import { useParams } from "wouter";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Send, ArrowLeft, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";

interface TicketDetail {
  id: number;
  ticketId: string;
  name: string;
  email: string;
  issue: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  responses: Array<{
    id: number;
    response: string;
    createdAt: string;
    isAdmin: boolean;
    admin?: {
      id: number;
      username: string;
      email: string;
    };
  }>;
}

export default function TicketView() {
  const { ticketId } = useParams();
  const [responseText, setResponseText] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: ticket, isLoading, refetch } = useQuery<TicketDetail>({
    queryKey: ["/api/tickets", ticketId, "details"],
    queryFn: async () => {
      const response = await fetch(`/api/tickets/${ticketId}/details`);
      if (!response.ok) {
        throw new Error('Ticket not found');
      }
      return response.json();
    },
    enabled: !!ticketId,
    refetchInterval: 5000, // Poll every 5 seconds for real-time updates
  });

  const addResponseMutation = useMutation({
    mutationFn: async (response: string) => {
      const res = await fetch(`/api/tickets/${ticketId}/responses`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ response }),
      });
      if (!res.ok) {
        throw new Error('Failed to add response');
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Response Added",
        description: "Your response has been sent successfully.",
      });
      setResponseText("");
      queryClient.invalidateQueries({ queryKey: ["/api/tickets", ticketId, "details"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add response.",
        variant: "destructive",
      });
    }
  });

  const handleAddResponse = () => {
    if (!responseText.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a response.",
        variant: "destructive",
      });
      return;
    }
    addResponseMutation.mutate(responseText);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open":
        return "bg-red-900/30 text-red-400 border-red-900/50";
      case "resolved":
        return "bg-green-900/30 text-green-400 border-green-900/50";
      case "closed":
        return "bg-gray-900/30 text-gray-400 border-gray-900/50";
      default:
        return "bg-gray-900/30 text-gray-400 border-gray-900/50";
    }
  };

  const formatTimeAgo = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch {
      return "Unknown time";
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#22c55e] mx-auto"></div>
          <p className="text-gray-400 mt-4">Loading ticket details...</p>
        </div>
      </div>
    );
  }

  if (!ticket) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex items-center justify-center">
        <Card className="w-full max-w-md mx-4 bg-[#1e293b] border-gray-700">
          <CardContent className="pt-6 text-center">
            <h1 className="text-2xl font-bold text-white mb-4">Ticket Not Found</h1>
            <p className="text-gray-400 mb-6">
              The ticket you're looking for doesn't exist or may have been removed.
            </p>
            <Link href="/">
              <Button className="bg-[#22c55e] text-black hover:bg-[#16a34a]">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0f172a] flex flex-col">
      {/* Header */}
      <div className="bg-[#1e293b] border-b border-[#334155] flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <img 
                src="https://indifferentbroccoli.com/img/broccoli_shadow_square.png" 
                alt="Logo" 
                className="h-8 w-8" 
              />
              <h1 className="text-xl font-bold text-white">Support Ticket</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                onClick={() => refetch()}
                className="text-gray-400 hover:text-white"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Link href="/">
                <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Home
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col overflow-hidden">
        {/* Ticket Information - Fixed header */}
        <div className="flex-shrink-0 mb-6">
          {/* Ticket Information */}
          <Card className="bg-[#1e293b] border-[#334155]">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <span>Ticket #{ticket.ticketId}</span>
                <Badge className={`border ${getStatusColor(ticket.status)}`}>
                  {ticket.status?.toUpperCase() || 'UNKNOWN'}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-400">Customer Name</Label>
                  <p className="text-white font-medium">{ticket.name}</p>
                </div>
                <div>
                  <Label className="text-gray-400">Email</Label>
                  <p className="text-white font-medium">{ticket.email}</p>
                </div>
              </div>
              <div>
                <Label className="text-gray-400">Issue Description</Label>
                <div className="bg-[#334155] rounded-lg p-4 border border-[#475569] mt-2 max-h-32 overflow-y-auto">
                  <p className="text-white whitespace-pre-wrap">{ticket.issue}</p>
                </div>
              </div>
              <div className="text-sm text-gray-400">
                Created {formatTimeAgo(ticket.createdAt)}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Conversation - Full height */}
        <div className="flex-1 flex flex-col min-h-0 mb-6">
          <Card className="bg-[#1e293b] border-[#334155] flex-1 flex flex-col overflow-hidden">
            <CardHeader className="flex-shrink-0">
              <CardTitle className="text-white">
                Conversation ({ticket.responses?.length || 0} responses)
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col overflow-hidden">
              <div className="flex-1 bg-[#0f172a] rounded-lg border border-[#334155] overflow-hidden flex flex-col">
                <div className="flex-1 overflow-y-auto p-4">
                  {!ticket.responses || ticket.responses.length === 0 ? (
                    <p className="text-gray-400 italic text-center py-8">No responses yet. Start the conversation below!</p>
                  ) : (
                    <div className="space-y-4">
                    {ticket.responses.map((response) => {
                      const isAdmin = response.admin?.id && response.admin.id > 0;
                      return (
                        <div 
                          key={response.id} 
                          className={`flex ${isAdmin ? 'justify-end' : 'justify-start'}`}
                        >
                          <div 
                            className={`rounded-lg p-4 border max-w-[75%] min-w-[200px] ${
                              isAdmin 
                                ? 'bg-blue-900/30 border-blue-800/50' 
                                : 'bg-green-900/30 border-green-800/50'
                            }`}
                          >
                            <div className="flex justify-between items-center mb-2">
                              <span className={`font-semibold text-sm ${
                                isAdmin ? 'text-blue-400' : 'text-green-400'
                              }`}>
                                {isAdmin ? `${response.admin?.username || 'Admin'}` : 'You'}
                              </span>
                              <span className="text-xs text-gray-400 ml-2">
                                {formatTimeAgo(response.createdAt)}
                              </span>
                            </div>
                            <p className="text-white whitespace-pre-wrap break-words text-sm leading-relaxed">{response.response}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Add Response - Fixed footer */}
        {ticket.status === "open" && (
          <div className="flex-shrink-0">
            <Card className="bg-[#1e293b] border-[#334155]">
              <CardHeader>
                <CardTitle className="text-white">Add Your Response</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="responseText" className="text-gray-400">Your message</Label>
                  <Textarea
                    id="responseText"
                    value={responseText}
                    onChange={(e) => setResponseText(e.target.value)}
                    placeholder="Type your response here... You can write as much as you need."
                    rows={4}
                    className="bg-[#334155] border-[#475569] text-white placeholder:text-gray-400 resize-none"
                    disabled={addResponseMutation.isPending}
                  />
                  <div className="text-sm text-gray-400">
                    {responseText.length} characters
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="text-sm text-gray-400">
                    Your response will be sent to the support team
                  </div>
                  <Button
                    onClick={handleAddResponse}
                    disabled={addResponseMutation.isPending || !responseText.trim()}
                    className="bg-[#22c55e] text-black hover:bg-[#16a34a] px-6"
                  >
                    {addResponseMutation.isPending ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-black mr-2"></div>
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Send Response
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {ticket.status !== "open" && (
          <div className="flex-shrink-0">
            <Card className="bg-yellow-900/20 border-yellow-800/50">
              <CardContent className="pt-6">
                <p className="text-yellow-400 text-center">
                  This ticket is {ticket.status}. No new responses can be added.
                </p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
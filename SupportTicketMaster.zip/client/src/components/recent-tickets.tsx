import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";

interface RecentTicket {
  ticketId: string;
  status: string;
  createdAt: string;
  issue: string;
}

export default function RecentTickets() {
  const { data: tickets = [], isLoading } = useQuery<RecentTicket[]>({
    queryKey: ["/api/tickets/recent"],
    staleTime: 30000, // 30 seconds
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open":
        return "bg-red-900/30 text-red-400 border-red-900/50";
      case "resolved":
        return "bg-green-900/30 text-green-400 border-green-900/50";
      case "closed":
        return "bg-gray-900/30 text-gray-400 border-gray-900/50";
      default:
        return "bg-gray-900/30 text-gray-400 border-gray-900/50";
    }
  };

  const formatTimeAgo = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch {
      return "Unknown time";
    }
  };

  if (isLoading) {
    return (
      <section className="py-16 bg-[#0f172a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-white">Recent Tickets</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-[#1e293b] rounded-xl p-6 border border-[#334155] animate-pulse">
                <div className="h-4 bg-gray-700 rounded w-3/4 mb-3"></div>
                <div className="h-3 bg-gray-700 rounded w-1/4 mb-4"></div>
                <div className="h-3 bg-gray-700 rounded w-full mb-2"></div>
                <div className="h-3 bg-gray-700 rounded w-2/3 mb-4"></div>
                <div className="flex justify-between items-center">
                  <div className="h-3 bg-gray-700 rounded w-1/3"></div>
                  <div className="h-3 bg-gray-700 rounded w-1/4"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-[#0f172a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-white">Recent Tickets</h2>
          <span className="text-[#22c55e] hover:text-green-400 font-medium transition-colors cursor-pointer">
            SEE MORE TICKETS →
          </span>
        </div>
        
        {tickets.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-400 text-lg">No tickets submitted yet</div>
            <p className="text-gray-500 mt-2">Be the first to submit a support ticket!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tickets.map((ticket) => (
              <div 
                key={ticket.ticketId} 
                className="bg-[#1e293b] rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-[#334155] hover:border-[#475569]"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="font-semibold text-lg text-white mb-1">
                      Support Ticket
                    </h3>
                    <p className="text-[#22c55e] text-sm font-medium">#{ticket.ticketId}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(ticket.status)}`}>
                    {ticket.status.toUpperCase()}
                  </span>
                </div>
                
                <p className="text-gray-300 text-sm mb-4 line-clamp-3">
                  {ticket.issue}
                </p>
                
                <div className="flex justify-between items-center text-sm text-gray-400">
                  <span>Support Request</span>
                  <span>{formatTimeAgo(ticket.createdAt)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

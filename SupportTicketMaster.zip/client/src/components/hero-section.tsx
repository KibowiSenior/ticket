import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";


interface HeroSectionProps {
  onSubmitTicket: () => void;
  onViewTickets: () => void;
}

export default function HeroSection({ onSubmitTicket, onViewTickets }: HeroSectionProps) {
  const [showTicketForm, setShowTicketForm] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    issue: ""
  });
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const submitTicketMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await apiRequest("POST", "/api/tickets", data);
    },
    onSuccess: async (response) => {
      const result = await response.json();
      toast({
        title: "Ticket Submitted Successfully!",
        description: `Your ticket ${result.ticketId} has been submitted. Redirecting to your ticket page...`,
      });
      setFormData({ name: "", email: "", issue: "" });
      setShowTicketForm(false);
      
      // Extract the numeric part from the ticket ID for routing
      const ticketNumber = result.ticketId.split('-')[1];
      setTimeout(() => {
        setLocation(`/ticket/${ticketNumber}`);
      }, 2000);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit ticket. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.email.trim() || !formData.issue.trim()) {
      toast({
        title: "Validation Error",
        description: "Please fill in all fields.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.email.includes("@")) {
      toast({
        title: "Validation Error",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
      return;
    }

    submitTicketMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (showTicketForm) {
    return (
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#1a2332]">
        <div className="absolute inset-0 bg-black bg-opacity-60"></div>
        <div className="relative z-10 max-w-2xl w-full mx-auto px-4">
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Need Help? Open a Ticket.
            </h1>
            <p className="text-gray-300 text-lg">
              Just enter your <span className="text-green-400">name and email</span> — we'll take it from there
            </p>
          </div>

          <div className="bg-[#1a2332] bg-opacity-90 rounded-lg p-8 backdrop-blur-sm border border-gray-700">
            <h2 className="text-2xl font-bold text-white mb-2 text-center">Submit Support Ticket</h2>
            <p className="text-gray-400 mb-6 text-center">Tell us about your issue and we'll help you out</p>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="name" className="text-white mb-2 block font-medium">Your Name</Label>
                <Input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="Enter your full name"
                  className="bg-[#2a3441] border-[#3a4551] text-white placeholder:text-gray-400 focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <Label htmlFor="email" className="text-white mb-2 block font-medium">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  placeholder="your.email@example.com"
                  className="bg-[#2a3441] border-[#3a4551] text-white placeholder:text-gray-400 focus:border-blue-500 focus:ring-blue-500"
                  required
                />
                <p className="text-sm text-gray-400 mt-1">Enter any valid email address</p>
              </div>

              <div>
                <Label htmlFor="issue" className="text-white mb-2 block font-medium">Issue Description</Label>
                <Textarea
                  id="issue"
                  value={formData.issue}
                  onChange={(e) => handleInputChange("issue", e.target.value)}
                  placeholder="Please describe your issue in detail. Include any error messages, steps to reproduce the problem, and what you expected to happen."
                  rows={6}
                  className="bg-[#2a3441] border-[#3a4551] text-white placeholder:text-gray-400 resize-none focus:border-blue-500 focus:ring-blue-500"
                  required
                />
                <p className="text-sm text-gray-400 mt-1">The more details you provide, the faster we can help you</p>
              </div>

              <div className="flex gap-4">
                <Button 
                  type="button"
                  variant="outline"
                  onClick={() => setShowTicketForm(false)}
                  className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white"
                >
                  Back
                </Button>
                <Button 
                  type="submit" 
                  disabled={submitTicketMutation.isPending}
                  className="flex-1 bg-[#22c55e] hover:bg-[#16a34a] text-black font-semibold"
                >
                  {submitTicketMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-black mr-2"></div>
                      Submitting...
                    </>
                  ) : (
                    "Submit Ticket"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#1a2332]">
      <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
        <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
          Need Help? Open a Ticket.
        </h1>
        <p className="text-xl md:text-2xl text-gray-200 mb-8">
          Just enter your <span className="text-green-400">name and email</span> — we'll take it from there
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={() => setShowTicketForm(true)}
            className="bg-[#22c55e] hover:bg-[#16a34a] text-black px-8 py-4 text-lg font-semibold"
          >
            SUBMIT TICKET
          </Button>
          <Button 
            onClick={onViewTickets}
            variant="outline"
            className="border-2 border-white text-white hover:bg-white hover:text-black px-8 py-4 text-lg font-semibold"
          >
            ALL TICKETS
          </Button>
        </div>
      </div>
    </section>
  );
}

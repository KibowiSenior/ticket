import { 
  type User, 
  type InsertUser, 
  type Ticket, 
  type InsertTicket, 
  type TicketResponse, 
  type InsertTicketResponse,
  type TicketWithRelations 
} from "@shared/schema";
import bcrypt from "bcrypt";
import fs from "fs/promises";
import path from "path";

// Define IStorage interface
interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  getAllAdmins(): Promise<User[]>;
  updateUserPassword(id: number, hashedPassword: string): Promise<boolean>;
  deleteUser(id: number): Promise<boolean>;
  
  // Ticket methods
  createTicket(insertTicket: InsertTicket): Promise<Ticket>;
  getTicketByTicketId(ticketId: string): Promise<Ticket | undefined>;
  getTicketWithResponses(id: number): Promise<TicketWithRelations | undefined>;
  getAllTickets(options?: { status?: string; search?: string; page?: number; limit?: number }): Promise<TicketWithRelations[]>;
  getRecentTickets(limit: number): Promise<Ticket[]>;
  updateTicketStatus(id: number, status: string, adminId: number): Promise<boolean>;
  deleteTicket(id: number): Promise<boolean>;
  
  // Response methods
  addTicketResponse(response: InsertTicketResponse & { adminId: number }): Promise<TicketResponse>;
  
  // Stats methods
  getAdminStats(): Promise<{
    totalTickets: number;
    openTickets: number;
    resolvedToday: number;
    myTickets: number;
  }>;
  
  getAdminPerformance(): Promise<Array<{
    admin: User;
    ticketsHandled: number;
    responsesGiven: number;
    avgResponseTime: number;
  }>>;
}

// Data storage paths
const DATA_DIR = path.join(process.cwd(), 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const TICKETS_FILE = path.join(DATA_DIR, 'tickets.json');
const RESPONSES_FILE = path.join(DATA_DIR, 'responses.json');

// Ensure data directory exists
async function ensureDataDir() {
  try {
    await fs.mkdir(DATA_DIR, { recursive: true });
  } catch (error) {
    // Directory already exists
  }
}

// Helper functions for file operations
async function readJsonFile<T>(filePath: string, defaultValue: T[] = []): Promise<T[]> {
  try {
    const data = await fs.readFile(filePath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    return defaultValue as T[];
  }
}

async function writeJsonFile<T>(filePath: string, data: T[]): Promise<void> {
  await ensureDataDir();
  await fs.writeFile(filePath, JSON.stringify(data, null, 2));
}

export class FileStorage implements IStorage {
  private initialized = false;

  async initialize() {
    if (this.initialized) return;
    
    // Check if default admin exists without calling getUserByEmail to avoid circular reference
    const users = await readJsonFile<User>(USERS_FILE);
    const existingAdmin = users.find(user => user.email === "gamerzofficail6@gmail.com");
    
    if (!existingAdmin) {
      // Create default admin user directly
      const hashedPassword = await bcrypt.hash("admin123", 10);
      const newAdmin: User = {
        id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
        username: "admin",
        email: "gamerzofficail6@gmail.com",
        password: hashedPassword,
        role: "admin",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      users.push(newAdmin);
      await writeJsonFile(USERS_FILE, users);
    }
    
    this.initialized = true;
  }

  async getUser(id: number): Promise<User | undefined> {
    await this.initialize();
    const users = await readJsonFile<User>(USERS_FILE);
    return users.find(user => user.id === id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    await this.initialize();
    const users = await readJsonFile<User>(USERS_FILE);
    return users.find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    await this.initialize();
    const users = await readJsonFile<User>(USERS_FILE);
    return users.find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const users = await readJsonFile<User>(USERS_FILE);
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    
    const newUser: User = {
      id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
      username: insertUser.username,
      email: insertUser.email,
      password: hashedPassword,
      role: insertUser.role || 'user',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    users.push(newUser);
    await writeJsonFile(USERS_FILE, users);
    return newUser;
  }

  async getAllAdmins(): Promise<User[]> {
    const users = await readJsonFile<User>(USERS_FILE);
    return users.filter(user => user.role === 'admin');
  }

  async updateUserPassword(id: number, hashedPassword: string): Promise<boolean> {
    const users = await readJsonFile<User>(USERS_FILE);
    const userIndex = users.findIndex(user => user.id === id);
    
    if (userIndex === -1) {
      return false;
    }

    users[userIndex].password = hashedPassword;
    users[userIndex].updatedAt = new Date().toISOString();
    
    await writeJsonFile(USERS_FILE, users);
    return true;
  }

  async deleteUser(id: number): Promise<boolean> {
    const users = await readJsonFile<User>(USERS_FILE);
    const userIndex = users.findIndex(user => user.id === id);
    
    if (userIndex === -1) {
      return false;
    }

    users.splice(userIndex, 1);
    await writeJsonFile(USERS_FILE, users);
    return true;
  }

  async createTicket(insertTicket: InsertTicket): Promise<Ticket> {
    const tickets = await readJsonFile<Ticket>(TICKETS_FILE);
    const ticketId = `TK-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
    
    const newTicket: Ticket = {
      id: tickets.length > 0 ? Math.max(...tickets.map(t => t.id)) + 1 : 1,
      ticketId,
      name: insertTicket.name,
      email: insertTicket.email,
      issue: insertTicket.issue,
      status: 'open',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      assignedTo: null
    };

    tickets.push(newTicket);
    await writeJsonFile(TICKETS_FILE, tickets);
    return newTicket;
  }

  async getTicketByTicketId(ticketId: string): Promise<Ticket | undefined> {
    const tickets = await readJsonFile<Ticket>(TICKETS_FILE);
    return tickets.find(ticket => ticket.ticketId === ticketId);
  }

  async getTicketWithResponses(id: number): Promise<TicketWithRelations | undefined> {
    const tickets = await readJsonFile<Ticket>(TICKETS_FILE);
    const responses = await readJsonFile<TicketResponse>(RESPONSES_FILE);
    const users = await readJsonFile<User>(USERS_FILE);
    
    const ticket = tickets.find(t => t.id === id);
    if (!ticket) return undefined;

    const ticketResponses = responses
      .filter(r => r.ticketId === id)
      .map(response => {
        const isUserResponse = response.adminId === 0;
        return {
          ...response,
          admin: isUserResponse ? null : users.find(u => u.id === response.adminId),
          isAdmin: !isUserResponse
        };
      })
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    const assignedAdmin = ticket.assignedTo ? users.find(u => u.id === ticket.assignedTo) : undefined;

    return {
      ...ticket,
      assignedAdmin,
      responses: ticketResponses
    } as TicketWithRelations;
  }

  async getAllTickets(options: { status?: string; search?: string; page?: number; limit?: number } = {}): Promise<TicketWithRelations[]> {
    const { status, search, page = 1, limit = 20 } = options;
    const tickets = await readJsonFile<Ticket>(TICKETS_FILE);
    const responses = await readJsonFile<TicketResponse>(RESPONSES_FILE);
    const users = await readJsonFile<User>(USERS_FILE);

    let filteredTickets = tickets;

    if (status) {
      filteredTickets = filteredTickets.filter(ticket => ticket.status === status);
    }

    if (search) {
      const searchLower = search.toLowerCase();
      filteredTickets = filteredTickets.filter(ticket =>
        ticket.name.toLowerCase().includes(searchLower) ||
        ticket.email.toLowerCase().includes(searchLower) ||
        ticket.issue.toLowerCase().includes(searchLower) ||
        ticket.ticketId.toLowerCase().includes(searchLower)
      );
    }

    // Sort by creation date (newest first)
    filteredTickets.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    // Pagination
    const offset = (page - 1) * limit;
    const paginatedTickets = filteredTickets.slice(offset, offset + limit);

    return paginatedTickets.map(ticket => {
      const ticketResponses = responses
        .filter(r => r.ticketId === ticket.id)
        .map(response => ({
          ...response,
          admin: users.find(u => u.id === response.adminId)!
        }));

      const assignedAdmin = ticket.assignedTo ? users.find(u => u.id === ticket.assignedTo) : undefined;

      return {
        ...ticket,
        assignedAdmin,
        responses: ticketResponses
      } as TicketWithRelations;
    });
  }

  async getRecentTickets(limit: number): Promise<Ticket[]> {
    const tickets = await readJsonFile<Ticket>(TICKETS_FILE);
    return tickets
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }

  async updateTicketStatus(id: number, status: string, adminId: number): Promise<boolean> {
    const tickets = await readJsonFile<Ticket>(TICKETS_FILE);
    const ticketIndex = tickets.findIndex(t => t.id === id);
    
    if (ticketIndex === -1) return false;

    tickets[ticketIndex] = {
      ...tickets[ticketIndex],
      status,
      assignedTo: adminId,
      updatedAt: new Date().toISOString()
    };

    await writeJsonFile(TICKETS_FILE, tickets);
    return true;
  }

  async deleteTicket(id: number): Promise<boolean> {
    const tickets = await readJsonFile<Ticket>(TICKETS_FILE);
    const responses = await readJsonFile<TicketResponse>(RESPONSES_FILE);
    
    const ticketIndex = tickets.findIndex(t => t.id === id);
    if (ticketIndex === -1) return false;

    // Remove the ticket
    tickets.splice(ticketIndex, 1);
    await writeJsonFile(TICKETS_FILE, tickets);

    // Remove all responses associated with this ticket
    const updatedResponses = responses.filter(r => r.ticketId !== id);
    await writeJsonFile(RESPONSES_FILE, updatedResponses);

    return true;
  }

  async addTicketResponse(response: InsertTicketResponse & { adminId: number }): Promise<TicketResponse> {
    const responses = await readJsonFile<TicketResponse>(RESPONSES_FILE);
    
    const newResponse: TicketResponse = {
      id: responses.length > 0 ? Math.max(...responses.map(r => r.id)) + 1 : 1,
      ticketId: response.ticketId,
      response: response.response,
      adminId: response.adminId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    responses.push(newResponse);
    await writeJsonFile(RESPONSES_FILE, responses);
    return newResponse;
  }

  async getAdminStats(): Promise<{
    totalTickets: number;
    openTickets: number;
    resolvedToday: number;
    myTickets: number;
  }> {
    const tickets = await readJsonFile<Ticket>(TICKETS_FILE);
    const today = new Date().toISOString().split('T')[0];

    const totalTickets = tickets.length;
    const openTickets = tickets.filter(t => t.status === 'open').length;
    const resolvedToday = tickets.filter(t => 
      t.status === 'resolved' && (t.updatedAt as string).startsWith(today)
    ).length;

    return {
      totalTickets,
      openTickets,
      resolvedToday,
      myTickets: 0 // Would need user context
    };
  }

  async getAdminPerformance(): Promise<Array<{
    admin: User;
    ticketsHandled: number;
    responsesGiven: number;
    avgResponseTime: number;
  }>> {
    const admins = await this.getAllAdmins();
    const tickets = await readJsonFile<Ticket>(TICKETS_FILE);
    const responses = await readJsonFile<TicketResponse>(RESPONSES_FILE);

    return admins.map(admin => {
      const ticketsHandled = tickets.filter(t => t.assignedTo === admin.id).length;
      const responsesGiven = responses.filter(r => r.adminId === admin.id).length;

      return {
        admin,
        ticketsHandled,
        responsesGiven,
        avgResponseTime: 0 // Simplified for now
      };
    });
  }
}

export const storage = new FileStorage();

// Initialize storage with default admin when module loads
storage.initialize();
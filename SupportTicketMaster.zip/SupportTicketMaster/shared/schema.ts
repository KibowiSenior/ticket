import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("admin"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  ticketId: varchar("ticket_id", { length: 50 }).notNull().unique(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  issue: text("issue").notNull(),
  status: text("status").notNull().default("open"), // open, resolved, closed
  assignedTo: integer("assigned_to"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});

export const ticketResponses = pgTable("ticket_responses", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").notNull(),
  adminId: integer("admin_id").notNull(),
  response: text("response").notNull(),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});

// Relations
export const ticketsRelations = relations(tickets, ({ one, many }) => ({
  assignedAdmin: one(users, {
    fields: [tickets.assignedTo],
    references: [users.id],
  }),
  responses: many(ticketResponses),
}));

export const ticketResponsesRelations = relations(ticketResponses, ({ one }) => ({
  ticket: one(tickets, {
    fields: [ticketResponses.ticketId],
    references: [tickets.id],
  }),
  admin: one(users, {
    fields: [ticketResponses.adminId],
    references: [users.id],
  }),
}));

export const usersRelations = relations(users, ({ many }) => ({
  assignedTickets: many(tickets),
  responses: many(ticketResponses),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  role: true,
});

export const createAdminSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
}).extend({
  role: z.literal("admin"),
});

export const insertTicketSchema = createInsertSchema(tickets).pick({
  name: true,
  email: true,
  issue: true,
}).extend({
  email: z.string().email("Must be a valid email address"),
  name: z.string().min(2, "Name must be at least 2 characters"),
  issue: z.string().min(10, "Issue description must be at least 10 characters"),
});

export const insertTicketResponseSchema = createInsertSchema(ticketResponses).pick({
  ticketId: true,
  response: true,
}).extend({
  response: z.string().min(5, "Response must be at least 5 characters"),
});

export const updateTicketStatusSchema = z.object({
  status: z.enum(["open", "resolved", "closed"]),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type CreateAdmin = z.infer<typeof createAdminSchema>;
export type Ticket = typeof tickets.$inferSelect;
export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type TicketResponse = typeof ticketResponses.$inferSelect;
export type InsertTicketResponse = z.infer<typeof insertTicketResponseSchema>;
export type UpdateTicketStatus = z.infer<typeof updateTicketStatusSchema>;

// Extended types with relations
export type TicketWithRelations = Ticket & {
  assignedAdmin?: User;
  responses: (TicketResponse & { admin: User })[];
};

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth.tsx";
import { useLocation } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { 
  TicketIcon, 
  ClockIcon, 
  CheckCircleIcon, 
  UserCheckIcon,
  EyeIcon,
  LogOutIcon,
  RefreshCwIcon,
  SearchIcon,
  Settings
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import TicketDetailModal from "@/components/ticket-detail-modal";

interface AdminStats {
  totalTickets: number;
  openTickets: number;
  resolvedToday: number;
  myTickets: number;
}

interface TicketWithRelations {
  id: number;
  ticketId: string;
  name: string;
  email: string;
  issue: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  assignedTo?: number;
  assignedAdmin?: {
    id: number;
    username: string;
    email: string;
  };
  responses: Array<{
    id: number;
    response: string;
    createdAt: string;
    admin: {
      id: number;
      username: string;
      email: string;
    };
  }>;
}

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchFilter, setSearchFilter] = useState("");
  const [selectedTicketId, setSelectedTicketId] = useState<number | null>(null);

  // Fetch admin stats
  const { data: stats } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
    staleTime: 30000,
  });

  // Fetch tickets with filters
  const { data: tickets = [], isLoading, refetch } = useQuery<TicketWithRelations[]>({
    queryKey: [
      "/api/admin/tickets", 
      { 
        status: statusFilter !== "all" ? statusFilter : undefined, 
        search: searchFilter || undefined 
      }
    ],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (statusFilter !== "all") {
        params.append("status", statusFilter);
      }
      if (searchFilter) {
        params.append("search", searchFilter);
      }
      
      const token = localStorage.getItem("auth_token");
      const url = `/api/admin/tickets${params.toString() ? `?${params.toString()}` : ''}`;
      
      const res = await fetch(url, {
        headers: {
          "Authorization": `Bearer ${token}`
        }
      });
      
      if (!res.ok) throw new Error("Failed to fetch tickets");
      return res.json();
    },
    staleTime: 10000,
  });

  const handleLogout = () => {
    logout();
    setLocation("/");
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open":
        return "bg-red-900/30 text-red-400 border-red-900/50";
      case "resolved":
        return "bg-green-900/30 text-green-400 border-green-900/50";
      case "closed":
        return "bg-gray-900/30 text-gray-400 border-gray-900/50";
      default:
        return "bg-gray-900/30 text-gray-400 border-gray-900/50";
    }
  };

  const formatTimeAgo = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch {
      return "Unknown time";
    }
  };

  const handleViewTicket = (ticketId: number) => {
    setSelectedTicketId(ticketId);
  };

  const handleTicketIdClick = (ticketId: string) => {
    setLocation(`/admin/${ticketId}`);
  };

  return (
    <div className="min-h-screen bg-[#0f172a]">
      {/* Admin Header */}
      <div className="bg-[#1e293b] border-b border-[#334155]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <img 
                src="https://indifferentbroccoli.com/img/broccoli_shadow_square.png" 
                alt="Logo" 
                className="h-8 w-8" 
              />
              <h1 className="text-xl font-bold text-white">Admin Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-gray-300">Welcome, {user?.username}</span>
              <Button 
                variant="ghost" 
                onClick={() => setLocation("/admin/manage")}
                className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/20"
              >
                <Settings className="h-4 w-4 mr-2" />
                Manage Admins
              </Button>
              <Button 
                variant="ghost" 
                onClick={handleLogout}
                className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
              >
                <LogOutIcon className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-[#1e293b] rounded-lg p-6 border border-[#334155]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Tickets</p>
                <p className="text-2xl font-bold text-[#3b82f6]">{stats?.totalTickets || 0}</p>
              </div>
              <TicketIcon className="text-[#3b82f6] h-8 w-8" />
            </div>
          </div>
          
          <div className="bg-[#1e293b] rounded-lg p-6 border border-[#334155]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Open Tickets</p>
                <p className="text-2xl font-bold text-red-400">{stats?.openTickets || 0}</p>
              </div>
              <ClockIcon className="text-red-400 h-8 w-8" />
            </div>
          </div>
          
          <div className="bg-[#1e293b] rounded-lg p-6 border border-[#334155]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Resolved Today</p>
                <p className="text-2xl font-bold text-[#22c55e]">{stats?.resolvedToday || 0}</p>
              </div>
              <CheckCircleIcon className="text-[#22c55e] h-8 w-8" />
            </div>
          </div>
          
          <div className="bg-[#1e293b] rounded-lg p-6 border border-[#334155]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">My Tickets</p>
                <p className="text-2xl font-bold text-[#8b5cf6]">{stats?.myTickets || 0}</p>
              </div>
              <UserCheckIcon className="text-[#8b5cf6] h-8 w-8" />
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-[#1e293b] rounded-lg p-6 border border-[#334155] mb-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-300">Status:</span>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40 bg-[#334155] border-[#475569] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#334155] border-[#475569] text-white">
                    <SelectItem value="all">All Tickets</SelectItem>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-300">Search:</span>
                <div className="relative">
                  <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    type="text"
                    placeholder="Search tickets..."
                    value={searchFilter}
                    onChange={(e) => setSearchFilter(e.target.value)}
                    className="pl-10 w-64 bg-[#334155] border-[#475569] text-white placeholder:text-gray-400"
                  />
                </div>
              </div>
            </div>
            
            <Button 
              onClick={() => refetch()}
              className="bg-[#22c55e] text-black hover:bg-[#16a34a]"
            >
              <RefreshCwIcon className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Deletion Notice */}
        <div className="bg-yellow-900/20 border border-yellow-700/50 rounded-lg p-4 mb-6">
          <div className="flex items-start space-x-3">
            <ClockIcon className="h-5 w-5 text-yellow-400 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-yellow-400">Automatic Deletion Policy</h4>
              <p className="text-sm text-yellow-300 mt-1">
                Tickets marked <strong>Resolved</strong> will be automatically deleted after 30 days.
                <br />
                Tickets marked <strong>Closed</strong> will be automatically deleted after 48 hours.
              </p>
            </div>
          </div>
        </div>

        {/* Tickets Table */}
        <div className="bg-[#1e293b] rounded-lg border border-[#334155] overflow-hidden">
          <div className="px-6 py-4 border-b border-[#334155]">
            <h3 className="text-lg font-semibold text-white">Support Tickets</h3>
          </div>
          
          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="p-8 text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#22c55e] mx-auto"></div>
                <p className="text-gray-400 mt-2">Loading tickets...</p>
              </div>
            ) : tickets.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-gray-400">No tickets found</p>
              </div>
            ) : (
              <table className="w-full">
                <thead className="bg-[#334155]">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Ticket ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Customer</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Issue</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Created</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#334155]">
                  {tickets.map((ticket) => (
                    <tr key={ticket.id} className="hover:bg-[#334155]/50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => handleTicketIdClick(ticket.ticketId)}
                          className="text-[#22c55e] hover:text-[#16a34a] hover:underline cursor-pointer transition-colors"
                        >
                          #{ticket.ticketId}
                        </button>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm text-white">{ticket.name}</div>
                          <div className="text-sm text-gray-400">{ticket.email}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-300 max-w-xs">
                        <div className="truncate" title={ticket.issue}>
                          {ticket.issue.length > 80 ? `${ticket.issue.substring(0, 80)}...` : ticket.issue}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold border ${getStatusColor(ticket.status)}`}>
                          {ticket.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                        {formatTimeAgo(ticket.createdAt)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleViewTicket(ticket.id)}
                          className="text-[#3b82f6] hover:text-blue-400 hover:bg-blue-900/20"
                        >
                          <EyeIcon className="h-4 w-4 mr-1" />
                          View
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      {/* Ticket Detail Modal */}
      {selectedTicketId && (
        <TicketDetailModal
          ticketId={selectedTicketId}
          isOpen={!!selectedTicketId}
          onClose={() => setSelectedTicketId(null)}
          onTicketUpdate={() => {
            refetch();
            if (stats) {
              // Refresh stats as well
              refetch();
            }
          }}
        />
      )}
    </div>
  );
}

import { Menu, X } from "lucide-react";
import { useState } from "react";

interface NavbarProps {
  onLoginClick: () => void;
  isLoggedIn: boolean;
}

export default function Navbar({ onLoginClick, isLoggedIn }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { href: "https://indifferentbroccoli.com/gameservers", text: "GAMES" },
    { href: "https://indifferentbroccoli.com/servers", text: "TOP SERVERS" },
    { href: "https://indifferentbroccoli.com/about-us", text: "ABOUT US" },
    { href: "https://indifferentbroccoli.com/contact-us", text: "CONTACT" },
    { href: "https://wiki.indifferentbroccoli.com/", text: "WIKI" },
    { href: "https://shop.indifferentbroccoli.com/", text: "MERCH" },
    { href: "https://boss.indifferentbroccoli.com/", text: "OPEN SOURCE" },
  ];

  return (
    <nav className="bg-[#0f172a] border-b border-[#334155] relative z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <img 
              src="https://indifferentbroccoli.com/img/broccoli_shadow_square.png" 
              alt="Indifferent Broccoli Logo" 
              className="h-8 w-8 mr-3" 
            />
            <span className="text-xl font-semibold text-white">Indifferent Broccoli</span>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              {navLinks.map((link) => (
                <a 
                  key={link.text}
                  href={link.href} 
                  className="text-slate-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {link.text}
                </a>
              ))}
            </div>
          </div>
          
          {/* Login Button & Mobile Menu */}
          <div className="flex items-center space-x-4">
            <button 
              onClick={onLoginClick}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                isLoggedIn 
                  ? "bg-[#22c55e] text-black hover:bg-[#16a34a]" 
                  : "bg-transparent border border-slate-600 text-white hover:border-[#22c55e]"
              }`}
            >
              {isLoggedIn ? "DASHBOARD" : "LOG IN"}
            </button>
            
            {/* Mobile menu button */}
            <button 
              className="md:hidden text-white"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-[#0f172a] border-b border-[#334155] z-40">
          <div className="px-4 py-4 space-y-2">
            {navLinks.map((link) => (
              <a 
                key={link.text}
                href={link.href} 
                className="block text-slate-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
              >
                {link.text}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}

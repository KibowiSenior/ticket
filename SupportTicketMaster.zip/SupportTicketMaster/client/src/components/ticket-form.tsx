import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { ArrowLeft, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface TicketFormProps {
  onBack: () => void;
}

export default function TicketForm({ onBack }: TicketFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    issue: ""
  });
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const submitTicketMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await apiRequest("POST", "/api/tickets", data);
    },
    onSuccess: async (response) => {
      const result = await response.json();
      toast({
        title: "Ticket Submitted Successfully!",
        description: `Your ticket ${result.ticketId} has been submitted. Redirecting to your ticket page...`,
      });
      setFormData({ name: "", email: "", issue: "" });
      
      // Extract the numeric part from the ticket ID for routing
      const ticketNumber = result.ticketId.split('-')[1];
      setTimeout(() => {
        setLocation(`/ticket/${ticketNumber}`);
      }, 2000);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit ticket. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.email.trim() || !formData.issue.trim()) {
      toast({
        title: "Validation Error",
        description: "Please fill in all fields.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.email.includes("@")) {
      toast({
        title: "Validation Error",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
      return;
    }

    submitTicketMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section className="py-16 bg-[#0f172a] min-h-screen pt-24">
      <div className="max-w-2xl mx-auto px-4">
        <div className="mb-6">
          <Button 
            variant="ghost" 
            onClick={onBack}
            className="text-gray-300 hover:text-white hover:bg-[#1e293b]"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </div>

        <div className="bg-[#1e293b] rounded-xl p-8 shadow-2xl border border-[#334155]">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-white mb-2">Submit Support Ticket</h2>
            <p className="text-gray-400">Tell us about your issue and we'll help you out</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="name" className="text-gray-300 mb-2 block">Your Name</Label>
              <Input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                placeholder="Enter your full name"
                className="input-field bg-[#334155] border-[#475569] text-white placeholder:text-gray-400"
                required
              />
            </div>

            <div>
              <Label htmlFor="email" className="text-gray-300 mb-2 block">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                placeholder="your.email@example.com"
                className="input-field bg-[#334155] border-[#475569] text-white placeholder:text-gray-400"
                required
              />
              <p className="text-sm text-gray-400 mt-1">Enter any valid email address</p>
            </div>

            <div>
              <Label htmlFor="issue" className="text-gray-300 mb-2 block">Issue Description</Label>
              <Textarea
                id="issue"
                value={formData.issue}
                onChange={(e) => handleInputChange("issue", e.target.value)}
                placeholder="Please describe your issue in detail. Include any error messages, steps to reproduce the problem, and what you expected to happen."
                rows={6}
                className="input-field bg-[#334155] border-[#475569] text-white placeholder:text-gray-400 resize-none"
                required
              />
              <p className="text-sm text-gray-400 mt-1">The more details you provide, the faster we can help you</p>
            </div>

            <Button 
              type="submit" 
              disabled={submitTicketMutation.isPending}
              className="w-full bg-[#22c55e] hover:bg-[#16a34a] text-black py-3 px-6 rounded-lg font-semibold transition-colors"
            >
              {submitTicketMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-black mr-2"></div>
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Submit Ticket
                </>
              )}
            </Button>
          </form>
        </div>
      </div>
    </section>
  );
}

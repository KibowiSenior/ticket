export default function ServerBanner() {
  return (
    <section className="bg-[#2563eb] py-4">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="text-white">
          <h3 className="text-lg font-semibold">Ready to host your server?</h3>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <a
            href="https://indifferentbroccoli.com/gameservers"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white text-[#2563eb] px-4 py-2 rounded text-sm font-medium hover:bg-gray-100 transition-colors"
          >
            LAUNCH YOUR SERVER
          </a>
          <a
            href="https://indifferentbroccoli.com/contact-us"
            target="_blank"
            rel="noopener noreferrer"
            className="border border-white text-white px-4 py-2 rounded text-sm font-medium hover:bg-white hover:text-[#2563eb] transition-colors"
          >
            GET HELP
          </a>
        </div>
      </div>
    </section>
  );
}
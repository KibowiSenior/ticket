import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { useAuth } from "@/lib/auth.tsx";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import { 
  ArrowLeftIcon, 
  SendIcon, 
  UserIcon, 
  ShieldCheckIcon,
  ClockIcon,
  CheckCircleIcon,
  XCircleIcon,
  TrashIcon
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

interface TicketDetail {
  id: number;
  ticketId: string;
  name: string;
  email: string;
  issue: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  assignedTo?: number;
  assignedAdmin?: {
    id: number;
    username: string;
    email: string;
  };
  responses: Array<{
    id: number;
    response: string;
    createdAt: string;
    isAdmin: boolean;
    admin?: {
      id: number;
      username: string;
      email: string;
    };
  }>;
}

export default function AdminTicketDetail() {
  const { ticketId } = useParams();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [newResponse, setNewResponse] = useState("");
  const [newStatus, setNewStatus] = useState("");

  // Fetch ticket details
  const { data: ticket, isLoading, error } = useQuery<TicketDetail>({
    queryKey: [`/api/admin/tickets/${ticketId}`],
    enabled: !!ticketId,
  });

  // Add response mutation
  const addResponseMutation = useMutation({
    mutationFn: async (response: string) => {
      const res = await fetch(`/api/admin/tickets/${ticket?.id}/responses`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem("auth_token")}`
        },
        body: JSON.stringify({ response })
      });
      if (!res.ok) throw new Error("Failed to add response");
      return res.json();
    },
    onSuccess: () => {
      setNewResponse("");
      queryClient.invalidateQueries({ queryKey: [`/api/admin/tickets/${ticketId}`] });
      toast({
        title: "Response Added",
        description: "Your response has been sent to the customer."
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send response. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Update status mutation
  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      const res = await fetch(`/api/admin/tickets/${ticket?.id}/status`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem("auth_token")}`
        },
        body: JSON.stringify({ status })
      });
      if (!res.ok) throw new Error("Failed to update status");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/admin/tickets/${ticketId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/tickets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Status Updated",
        description: `Ticket status changed to ${newStatus}`
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update ticket status. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Delete ticket mutation
  const deleteTicketMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`/api/admin/tickets/${ticket?.id}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("auth_token")}`
        }
      });
      if (!res.ok) throw new Error("Failed to delete ticket");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/tickets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Ticket Deleted",
        description: "Ticket has been permanently deleted."
      });
      setLocation("/admin");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete ticket. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleSendResponse = () => {
    if (!newResponse.trim()) return;
    addResponseMutation.mutate(newResponse.trim());
  };

  const handleStatusChange = (status: string) => {
    setNewStatus(status);
    updateStatusMutation.mutate(status);
  };

  const handleDeleteTicket = () => {
    if (window.confirm(`Are you sure you want to permanently delete ticket #${ticket?.ticketId}? This action cannot be undone.`)) {
      deleteTicketMutation.mutate();
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open":
        return "bg-red-900/30 text-red-400 border-red-900/50";
      case "resolved":
        return "bg-green-900/30 text-green-400 border-green-900/50";
      case "closed":
        return "bg-gray-900/30 text-gray-400 border-gray-900/50";
      default:
        return "bg-gray-900/30 text-gray-400 border-gray-900/50";
    }
  };

  const formatTimeAgo = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch {
      return "Unknown time";
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#22c55e] mx-auto"></div>
          <p className="text-gray-400 mt-4">Loading ticket details...</p>
        </div>
      </div>
    );
  }

  if (!ticket) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Ticket Not Found</h2>
          <p className="text-gray-400 mb-6">The ticket you're looking for doesn't exist.</p>
          <Button onClick={() => setLocation("/admin")} className="bg-[#22c55e] text-black hover:bg-[#16a34a]">
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0f172a]">
      {/* Header */}
      <div className="bg-[#1e293b] border-b border-[#334155]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => setLocation("/admin")}
                className="text-gray-300 hover:text-white hover:bg-gray-700"
              >
                <ArrowLeftIcon className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
              <div>
                <h1 className="text-xl font-bold text-white">Ticket #{ticket.ticketId}</h1>
                <p className="text-sm text-gray-400">Admin Panel</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(ticket?.status || '')}`}>
                {ticket?.status?.toUpperCase() || 'UNKNOWN'}
              </span>
              <Button
                variant="outline"
                onClick={handleDeleteTicket}
                disabled={deleteTicketMutation.isPending}
                className="border-red-600 text-red-400 hover:bg-red-900/20 hover:text-red-300"
              >
                {deleteTicketMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-400 mr-2"></div>
                    Deleting...
                  </>
                ) : (
                  <>
                    <TrashIcon className="h-4 w-4 mr-2" />
                    Delete Ticket
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Ticket Info */}
        <div className="bg-[#1e293b] rounded-lg p-6 border border-[#334155] mb-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Customer Information</h3>
              <div className="space-y-2">
                <p className="text-gray-300"><span className="text-gray-400">Name:</span> {ticket?.name || 'N/A'}</p>
                <p className="text-gray-300"><span className="text-gray-400">Email:</span> {ticket?.email || 'N/A'}</p>
                <p className="text-gray-300"><span className="text-gray-400">Created:</span> {ticket?.createdAt ? formatTimeAgo(ticket.createdAt) : 'N/A'}</p>
                <p className="text-gray-300"><span className="text-gray-400">Last Updated:</span> {ticket?.updatedAt ? formatTimeAgo(ticket.updatedAt) : 'N/A'}</p>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Ticket Management</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Status</label>
                  <Select value={ticket?.status || ''} onValueChange={handleStatusChange}>
                    <SelectTrigger className="w-full bg-[#334155] border-[#475569] text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-[#334155] border-[#475569] text-white">
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {ticket?.assignedAdmin && (
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Assigned To</label>
                    <p className="text-white">{ticket.assignedAdmin.username}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <h3 className="text-lg font-semibold text-white mb-2">Original Issue</h3>
            <div className="bg-[#334155] rounded-lg p-4 max-w-full overflow-hidden">
              <p className="text-gray-300 whitespace-pre-wrap break-words leading-relaxed">{ticket?.issue || 'No issue description available'}</p>
            </div>
          </div>
        </div>

        {/* Conversation */}
        <div className="bg-[#1e293b] rounded-lg border border-[#334155] mb-6">
          <div className="px-6 py-4 border-b border-[#334155]">
            <h3 className="text-lg font-semibold text-white">Conversation</h3>
          </div>
          
          <div className="p-6 space-y-6 max-h-[500px] overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-gray-800">
            {!ticket?.responses || ticket.responses.length === 0 ? (
              <p className="text-gray-400 text-center py-8">No responses yet. Be the first to reply!</p>
            ) : (
              ticket.responses.map((response) => (
                <div key={response.id} className={`flex ${response.isAdmin ? 'justify-end' : 'justify-start'} mb-4`}>
                  <div className={`flex ${response.isAdmin ? 'flex-row-reverse space-x-reverse' : 'flex-row'} space-x-3 max-w-5xl w-full`}>
                    <div className="flex-shrink-0">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg ${
                        response.isAdmin ? 'bg-blue-600' : 'bg-green-600'
                      }`}>
                        {response.isAdmin ? (
                          <ShieldCheckIcon className="h-5 w-5 text-white" />
                        ) : (
                          <UserIcon className="h-5 w-5 text-white" />
                        )}
                      </div>
                    </div>
                    <div className={`flex-1 min-w-0 ${response.isAdmin ? 'text-right' : 'text-left'}`}>
                      <div className={`inline-block p-4 rounded-lg max-w-full shadow-md ${
                        response.isAdmin 
                          ? 'bg-blue-600 text-white' 
                          : 'bg-[#334155] text-gray-300'
                      }`}>
                        <div className="whitespace-pre-wrap break-words leading-relaxed text-sm overflow-hidden">{response.response}</div>
                      </div>
                      <div className={`mt-2 text-xs text-gray-400 ${response.isAdmin ? 'text-right' : 'text-left'}`}>
                        {response.isAdmin && response.admin ? (
                          <span className="font-medium">{response.admin.username} • {formatTimeAgo(response.createdAt)}</span>
                        ) : (
                          <span className="font-medium">{ticket?.name || 'Customer'} • {formatTimeAgo(response.createdAt)}</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Response Form */}
        <div className="bg-[#1e293b] rounded-lg p-6 border border-[#334155]">
          <h3 className="text-lg font-semibold text-white mb-4">Add Response</h3>
          <div className="space-y-4">
            <div className="relative">
              <Textarea
                placeholder="Type your response here..."
                value={newResponse}
                onChange={(e) => setNewResponse(e.target.value)}
                className="min-h-32 w-full bg-[#334155] border-[#475569] text-white placeholder:text-gray-400 resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                style={{ 
                  height: 'auto',
                  minHeight: '8rem',
                  maxHeight: '16rem'
                }}
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = 'auto';
                  target.style.height = Math.min(target.scrollHeight, 256) + 'px';
                }}
              />
              <div className="mt-2 text-xs text-gray-400">
                {newResponse.length} characters
              </div>
            </div>
            <div className="flex justify-end">
              <Button
                onClick={handleSendResponse}
                disabled={!newResponse.trim() || addResponseMutation.isPending}
                className="bg-[#22c55e] text-black hover:bg-[#16a34a] disabled:bg-gray-600 disabled:text-gray-400"
              >
                {addResponseMutation.isPending ? (
                  <>
                    <ClockIcon className="h-4 w-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <SendIcon className="h-4 w-4 mr-2" />
                    Send Response
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>

        {/* Deletion Notice */}
        <div className="mt-6 bg-yellow-900/20 border border-yellow-700/50 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <ClockIcon className="h-5 w-5 text-yellow-400 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-yellow-400">Automatic Deletion Policy</h4>
              <p className="text-sm text-yellow-300 mt-1">
                Tickets marked <strong>Resolved</strong> will be automatically deleted after 30 days.
                <br />
                Tickets marked <strong>Closed</strong> will be automatically deleted after 48 hours.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
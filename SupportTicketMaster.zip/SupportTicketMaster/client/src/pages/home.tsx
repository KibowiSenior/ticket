import { useState } from "react";
import { useLocation } from "wouter";
import Navbar from "@/components/navbar";
import HeroSection from "@/components/hero-section";
import TicketForm from "@/components/ticket-form";
import ServerBanner from "@/components/server-banner";
import Footer from "@/components/footer";
import LoginModal from "@/components/login-modal";
import { useAuth } from "@/lib/auth.tsx";

export default function Home() {
  const [, setLocation] = useLocation();
  const [showTicketForm, setShowTicketForm] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const { user } = useAuth();

  const handleLoginClick = () => {
    if (user) {
      setLocation("/admin");
    } else {
      setShowLoginModal(true);
    }
  };

  const handleSubmitTicketClick = () => {
    setShowTicketForm(true);
  };

  const handleViewTicketsClick = () => {
    if (user) {
      setLocation("/admin");
    } else {
      setShowLoginModal(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#0f172a]">
      <Navbar onLoginClick={handleLoginClick} isLoggedIn={!!user} />
      
      {!showTicketForm ? (
        <>
          <HeroSection 
            onSubmitTicket={handleSubmitTicketClick}
            onViewTickets={handleViewTicketsClick}
          />
          <ServerBanner />
          <Footer />
        </>
      ) : (
        <>
          <TicketForm onBack={() => setShowTicketForm(false)} />
          <ServerBanner />
          <Footer />
        </>
      )}

      <LoginModal 
        isOpen={showLoginModal} 
        onClose={() => setShowLoginModal(false)} 
      />
    </div>
  );
}

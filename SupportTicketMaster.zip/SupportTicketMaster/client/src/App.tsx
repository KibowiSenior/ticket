import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/lib/auth.tsx";
import Home from "@/pages/home";
import Admin from "@/pages/admin";
import AdminManagement from "@/pages/admin-management";
import AdminTicketDetail from "@/pages/admin-ticket-detail";
import TicketView from "@/pages/ticket-view";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/admin" component={Admin} />
      <Route path="/admin/manage" component={AdminManagement} />
      <Route path="/admin/:ticketId" component={AdminTicketDetail} />
      <Route path="/ticket/:ticketId" component={TicketView} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <div className="min-h-screen bg-[#0f172a] text-white">
            <Toaster />
            <Router />
          </div>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;

import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTicketSchema, insertTicketResponseSchema, updateTicketStatusSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Middleware to verify JWT token
function authenticateToken(req: any, res: any, next: any) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize default admin user if not exists
  try {
    const existingAdmin = await storage.getUserByEmail("gamerzofficail6@gmail.com");
    if (!existingAdmin) {
      const hashedPassword = await bcrypt.hash("admin123", 10);
      await storage.createUser({
        username: "admin",
        email: "gamerzofficail6@gmail.com",
        password: hashedPassword,
        role: "admin"
      });
    }
  } catch (error) {
    console.error("Error initializing admin user:", error);
  }

  // Public Routes

  // Submit a new ticket
  app.post("/api/tickets", async (req, res) => {
    try {
      const validatedData = insertTicketSchema.parse(req.body);
      const ticket = await storage.createTicket(validatedData);
      res.status(201).json({ 
        message: "Ticket submitted successfully", 
        ticketId: ticket.ticketId 
      });
    } catch (error: any) {
      res.status(400).json({ 
        message: "Validation error", 
        details: error.message 
      });
    }
  });

  // Get public ticket status by ticket ID
  app.get("/api/tickets/:ticketId/status", async (req, res) => {
    try {
      const ticket = await storage.getTicketByTicketId(req.params.ticketId);
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      res.json({
        ticketId: ticket.ticketId,
        status: ticket.status,
        createdAt: ticket.createdAt,
        updatedAt: ticket.updatedAt
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get public ticket details with responses by ticket ID
  app.get("/api/tickets/:ticketId/details", async (req, res) => {
    try {
      let ticketId = req.params.ticketId;
      
      // If it's just a number, try to find the full ticket ID
      if (!ticketId.startsWith('TK-')) {
        const allTickets = await storage.getAllTickets();
        const foundTicket = allTickets.find(t => t.ticketId.includes(ticketId));
        if (foundTicket) {
          ticketId = foundTicket.ticketId;
        }
      }

      const ticket = await storage.getTicketByTicketId(ticketId);
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      const ticketWithResponses = await storage.getTicketWithResponses(ticket.id);
      if (!ticketWithResponses) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      res.json(ticketWithResponses);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Add public response to ticket
  app.post("/api/tickets/:ticketId/responses", async (req, res) => {
    try {
      let ticketId = req.params.ticketId;
      
      // If it's just a number, try to find the full ticket ID
      if (!ticketId.startsWith('TK-')) {
        const allTickets = await storage.getAllTickets();
        const foundTicket = allTickets.find(t => t.ticketId.includes(ticketId));
        if (foundTicket) {
          ticketId = foundTicket.ticketId;
        }
      }

      const ticket = await storage.getTicketByTicketId(ticketId);
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      if (ticket.status !== 'open') {
        return res.status(400).json({ message: "Cannot add response to closed ticket" });
      }

      const { response } = req.body;
      if (!response || !response.trim()) {
        return res.status(400).json({ message: "Response content is required" });
      }

      // Store user responses with adminId = 0 to distinguish from admin responses
      const userResponse = await storage.addTicketResponse({
        ticketId: ticket.id,
        response: response.trim(),
        adminId: 0 // Special ID for user responses
      });

      res.status(201).json({ 
        message: "Response added successfully",
        response: userResponse 
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get recent tickets (limited info for public display)
  app.get("/api/tickets/recent", async (req, res) => {
    try {
      const tickets = await storage.getRecentTickets(6);
      const publicTickets = tickets.map(ticket => ({
        ticketId: ticket.ticketId,
        status: ticket.status,
        createdAt: ticket.createdAt,
        issue: ticket.issue.length > 100 ? ticket.issue.substring(0, 100) + "..." : ticket.issue
      }));
      res.json(publicTickets);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Authentication Routes

  // Admin login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign(
        { userId: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: "24h" }
      );

      res.json({
        token,
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          role: user.role
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Verify token
  app.post("/api/auth/verify", authenticateToken, (req: any, res) => {
    res.json({ user: req.user });
  });

  // Protected Admin Routes

  // Get all tickets (admin only)
  app.get("/api/admin/tickets", authenticateToken, async (req: any, res) => {
    try {
      const { status, search, page = 1, limit = 20 } = req.query;
      const tickets = await storage.getAllTickets({
        status: status as string,
        search: search as string,
        page: parseInt(page as string),
        limit: parseInt(limit as string)
      });
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get ticket details with responses (admin only)
  app.get("/api/admin/tickets/:id", authenticateToken, async (req: any, res) => {
    try {
      let ticketId = req.params.id;
      let ticket;
      
      // If it's a numeric ID, use it directly
      if (!isNaN(parseInt(ticketId))) {
        ticket = await storage.getTicketWithResponses(parseInt(ticketId));
      } else {
        // If it's a ticketId string, find the ticket first
        const foundTicket = await storage.getTicketByTicketId(ticketId);
        if (foundTicket) {
          ticket = await storage.getTicketWithResponses(foundTicket.id);
        }
      }
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      res.json(ticket);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Update ticket status (admin only)
  app.patch("/api/admin/tickets/:id/status", authenticateToken, async (req: any, res) => {
    try {
      let ticketId = req.params.id;
      let numericTicketId;
      
      // If it's a numeric ID, use it directly
      if (!isNaN(parseInt(ticketId))) {
        numericTicketId = parseInt(ticketId);
      } else {
        // If it's a ticketId string, find the ticket first
        const foundTicket = await storage.getTicketByTicketId(ticketId);
        if (!foundTicket) {
          return res.status(404).json({ message: "Ticket not found" });
        }
        numericTicketId = foundTicket.id;
      }
      
      const validatedData = updateTicketStatusSchema.parse(req.body);
      const updated = await storage.updateTicketStatus(numericTicketId, validatedData.status, req.user.userId);
      
      if (!updated) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      res.json({ message: "Ticket status updated successfully" });
    } catch (error: any) {
      res.status(400).json({ 
        message: "Validation error", 
        details: error.message 
      });
    }
  });

  // Add response to ticket (admin only)
  app.post("/api/admin/tickets/:id/responses", authenticateToken, async (req: any, res) => {
    try {
      let ticketId = req.params.id;
      let numericTicketId;
      
      // If it's a numeric ID, use it directly
      if (!isNaN(parseInt(ticketId))) {
        numericTicketId = parseInt(ticketId);
      } else {
        // If it's a ticketId string, find the ticket first
        const foundTicket = await storage.getTicketByTicketId(ticketId);
        if (!foundTicket) {
          return res.status(404).json({ message: "Ticket not found" });
        }
        numericTicketId = foundTicket.id;
      }
      
      const responseData = {
        ticketId: numericTicketId,
        response: req.body.response
      };
      
      const validatedData = insertTicketResponseSchema.parse(responseData);
      const response = await storage.addTicketResponse({
        ...validatedData,
        adminId: req.user.userId
      });

      res.status(201).json({ 
        message: "Response added successfully",
        response 
      });
    } catch (error: any) {
      res.status(400).json({ 
        message: "Validation error", 
        details: error.message 
      });
    }
  });

  // Delete ticket (admin only)
  app.delete("/api/admin/tickets/:id", authenticateToken, async (req: any, res) => {
    try {
      let ticketId = req.params.id;
      let numericTicketId;
      
      // If it's a numeric ID, use it directly
      if (!isNaN(parseInt(ticketId))) {
        numericTicketId = parseInt(ticketId);
      } else {
        // If it's a ticketId string, find the ticket first
        const foundTicket = await storage.getTicketByTicketId(ticketId);
        if (!foundTicket) {
          return res.status(404).json({ message: "Ticket not found" });
        }
        numericTicketId = foundTicket.id;
      }
      
      const deleted = await storage.deleteTicket(numericTicketId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      res.json({ message: "Ticket deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ 
        message: "Internal server error", 
        details: error.message 
      });
    }
  });

  // Get admin dashboard stats
  app.get("/api/admin/stats", authenticateToken, async (req: any, res) => {
    try {
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get all admins
  app.get("/api/admins", authenticateToken, async (req: any, res) => {
    try {
      const admins = await storage.getAllAdmins();
      // Remove passwords from response
      const safeAdmins = admins.map(admin => {
        const { password, ...safeAdmin } = admin;
        return safeAdmin;
      });
      res.json(safeAdmins);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Create new admin
  app.post("/api/admins", authenticateToken, async (req: any, res) => {
    try {
      const { username, email, password } = req.body;
      
      if (!username || !email || !password) {
        return res.status(400).json({ message: "Username, email, and password are required" });
      }

      // Check if email already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(409).json({ message: "Email already exists" });
      }

      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(username);
      if (existingUsername) {
        return res.status(409).json({ message: "Username already exists" });
      }

      const newAdmin = await storage.createUser({
        username,
        email,
        password,
        role: "admin"
      });

      // Remove password from response
      const { password: _, ...safeAdmin } = newAdmin;
      res.status(201).json(safeAdmin);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get admin performance metrics
  app.get("/api/admin-performance", authenticateToken, async (req: any, res) => {
    try {
      const performance = await storage.getAdminPerformance();
      res.json(performance);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Change admin password
  app.patch("/api/admins/:id/password", authenticateToken, async (req: any, res) => {
    try {
      const adminId = parseInt(req.params.id);
      const { password } = req.body;

      if (!password || password.length < 6) {
        return res.status(400).json({ message: "Password must be at least 6 characters long" });
      }

      const admin = await storage.getUser(adminId);
      if (!admin) {
        return res.status(404).json({ message: "Admin not found" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const success = await storage.updateUserPassword(adminId, hashedPassword);
      
      if (!success) {
        return res.status(500).json({ message: "Failed to update password" });
      }

      res.json({ message: "Password updated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Delete admin
  app.delete("/api/admins/:id", authenticateToken, async (req: any, res) => {
    try {
      const adminId = parseInt(req.params.id);
      
      // Prevent deleting yourself
      if (req.user.userId === adminId) {
        return res.status(400).json({ message: "Cannot delete your own account" });
      }

      const admin = await storage.getUser(adminId);
      if (!admin) {
        return res.status(404).json({ message: "Admin not found" });
      }

      if (admin.role !== "admin") {
        return res.status(400).json({ message: "User is not an admin" });
      }

      const success = await storage.deleteUser(adminId);
      
      if (!success) {
        return res.status(500).json({ message: "Failed to delete admin" });
      }

      res.json({ message: "Admin deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

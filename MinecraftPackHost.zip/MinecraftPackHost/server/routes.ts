import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertResourcePackSchema } from "@shared/schema";
import multer from "multer";
import crypto from "crypto";
import { google } from "googleapis";
import path from "path";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 95 * 1024 * 1024, // 95MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.zip', '.mcpack'];
    const fileExtension = file.originalname.toLowerCase().substring(file.originalname.lastIndexOf('.'));
    if (allowedTypes.includes(fileExtension)) {
      cb(null, true);
    } else {
      cb(new Error('Only .zip and .mcpack files are allowed'));
    }
  }
});

// Google OAuth2 configuration
const getRedirectUri = () => {
  const replitDomains = process.env.REPLIT_DOMAINS;
  if (replitDomains) {
    const domains = replitDomains.split(',');
    return `https://${domains[0]}/auth/callback`;
  }
  return process.env.GOOGLE_REDIRECT_URI || 'http://localhost:5000/auth/callback';
};

const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID || process.env.VITE_GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET || process.env.VITE_GOOGLE_CLIENT_SECRET,
  getRedirectUri()
);

const drive = google.drive({ version: 'v3', auth: oauth2Client });

export async function registerRoutes(app: Express): Promise<Server> {
  
  // OAuth callback route - serves the callback page
  app.get("/auth/callback", (req, res) => {
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>MCPacks - Authentication</title>
        <style>
          body { font-family: Inter, sans-serif; margin: 0; padding: 20px; background: #f8f9fa; }
          .container { max-width: 400px; margin: 50px auto; text-align: center; }
          .minecraft-block { 
            background: linear-gradient(135deg, #6B9B47 0%, #4F7942 100%);
            border-radius: 8px;
            width: 64px;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
          }
          .spinner { 
            width: 32px; 
            height: 32px; 
            border: 4px solid white; 
            border-top: 4px solid transparent; 
            border-radius: 50%; 
            animation: spin 1s linear infinite; 
          }
          @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="minecraft-block">
            <div class="spinner"></div>
          </div>
          <h2>Connecting to Google Drive</h2>
          <p>Please wait while we complete the authentication...</p>
        </div>
        <script>
          const urlParams = new URLSearchParams(window.location.search);
          const code = urlParams.get('code');
          const error = urlParams.get('error');
          
          if (error) {
            if (window.opener) {
              window.opener.postMessage({
                type: 'OAUTH_ERROR',
                error: error
              }, window.location.origin);
            }
          } else if (code) {
            fetch('/api/auth/google/callback', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ code })
            })
            .then(response => response.json())
            .then(data => {
              if (window.opener) {
                window.opener.postMessage({
                  type: 'OAUTH_SUCCESS',
                  user: data.user,
                  tokens: data.tokens
                }, window.location.origin);
              }
            })
            .catch(error => {
              if (window.opener) {
                window.opener.postMessage({
                  type: 'OAUTH_ERROR',
                  error: error.message || 'Authentication failed'
                }, window.location.origin);
              }
            });
          }
        </script>
      </body>
      </html>
    `);
  });
  
  // Google OAuth routes
  app.get("/api/auth/google", (req, res) => {
    const scopes = [
      'https://www.googleapis.com/auth/userinfo.email',
      'https://www.googleapis.com/auth/userinfo.profile',
      'https://www.googleapis.com/auth/drive.file'
    ];
    
    const url = oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent'
    });
    
    res.json({ url });
  });

  app.post("/api/auth/google/callback", async (req, res) => {
    try {
      const { code } = req.body;
      
      if (!code) {
        return res.status(400).json({ message: 'Authorization code is required' });
      }
      
      const { tokens } = await oauth2Client.getAccessToken(code);
      
      if (!tokens.access_token) {
        throw new Error('Failed to obtain access token');
      }
      
      oauth2Client.setCredentials(tokens);
      
      // Get user info
      const oauth2 = google.oauth2({ version: 'v2', auth: oauth2Client });
      const { data: userInfo } = await oauth2.userinfo.get();
      
      if (!userInfo.email || !userInfo.name) {
        throw new Error('Failed to get user information from Google');
      }
      
      // Find or create user
      let user = await storage.getUserByEmail(userInfo.email);
      if (!user) {
        user = await storage.createUser({
          email: userInfo.email,
          name: userInfo.name,
          googleDriveId: userInfo.id
        });
      }
      
      // Update tokens
      const updatedUser = await storage.updateUser(user.id, {
        accessToken: tokens.access_token,
        refreshToken: tokens.refresh_token || user.refreshToken
      });
      
      res.json({ 
        user: updatedUser, 
        tokens: {
          access_token: tokens.access_token,
          refresh_token: tokens.refresh_token
        }
      });
    } catch (error: any) {
      console.error('OAuth callback error:', error);
      res.status(500).json({ message: error.message || 'Authentication failed' });
    }
  });

  // User routes
  app.get("/api/user/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(user);
    } catch (error) {
      console.error('Get user error:', error);
      res.status(500).json({ message: 'Failed to get user' });
    }
  });

  app.get("/api/user/:id/stats", async (req, res) => {
    try {
      const stats = await storage.getUserStats(req.params.id);
      res.json(stats);
    } catch (error) {
      console.error('Get user stats error:', error);
      res.status(500).json({ message: 'Failed to get user stats' });
    }
  });

  // Resource pack routes
  app.post("/api/upload", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      const { userId, accessToken } = req.body;
      
      if (!userId || !accessToken) {
        return res.status(401).json({ message: 'Authentication required' });
      }

      // Validate file size and type
      const maxSize = 95 * 1024 * 1024; // 95MB
      if (req.file.size > maxSize) {
        return res.status(400).json({ message: 'File size must be less than 95MB' });
      }

      const allowedTypes = ['.zip', '.mcpack'];
      const fileExtension = req.file.originalname.toLowerCase().substring(req.file.originalname.lastIndexOf('.'));
      if (!allowedTypes.includes(fileExtension)) {
        return res.status(400).json({ message: 'Only .zip and .mcpack files are allowed' });
      }

      // Set up OAuth client with user's tokens
      oauth2Client.setCredentials({ access_token: accessToken });

      // Calculate SHA-1 hash
      const sha1Hash = crypto.createHash('sha1').update(req.file.buffer).digest('hex');

      // Create MCPacks folder if it doesn't exist
      const folderName = 'MCPacks';
      let folderId;
      
      try {
        const folderResponse = await drive.files.list({
          q: `name='${folderName}' and mimeType='application/vnd.google-apps.folder' and trashed=false`,
          fields: 'files(id, name)',
          spaces: 'drive'
        });

        if (folderResponse.data.files && folderResponse.data.files.length > 0) {
          folderId = folderResponse.data.files[0].id;
        } else {
          const createFolderResponse = await drive.files.create({
            requestBody: {
              name: folderName,
              mimeType: 'application/vnd.google-apps.folder'
            },
            fields: 'id'
          });
          folderId = createFolderResponse.data.id;
        }
      } catch (driveError: any) {
        console.error('Drive folder error:', driveError);
        return res.status(500).json({ 
          message: 'Failed to access Google Drive. Please check your permissions.',
          error: driveError.message 
        });
      }

      if (!folderId) {
        return res.status(500).json({ message: 'Failed to create or access MCPacks folder' });
      }

      // Upload file to Google Drive
      let driveResponse;
      try {
        driveResponse = await drive.files.create({
          requestBody: {
            name: req.file.originalname,
            parents: [folderId]
          },
          media: {
            mimeType: req.file.mimetype || 'application/zip',
            body: req.file.buffer
          },
          fields: 'id, name, size'
        });

        if (!driveResponse.data.id) {
          throw new Error('Failed to get file ID from Google Drive');
        }

        // Make file publicly accessible
        await drive.permissions.create({
          fileId: driveResponse.data.id,
          requestBody: {
            role: 'reader',
            type: 'anyone'
          }
        });

      } catch (uploadError: any) {
        console.error('Drive upload error:', uploadError);
        return res.status(500).json({ 
          message: 'Failed to upload file to Google Drive',
          error: uploadError.message 
        });
      }

      // Generate direct download URL
      const downloadUrl = `https://drive.google.com/uc?id=${driveResponse.data.id}&export=download`;

      // Save to storage
      const resourcePack = await storage.createResourcePack({
        userId,
        fileName: req.file.originalname,
        originalName: req.file.originalname,
        fileSize: req.file.size,
        sha1Hash,
        driveFileId: driveResponse.data.id,
        downloadUrl
      });

      res.json({
        id: resourcePack.id,
        fileName: resourcePack.fileName,
        fileSize: resourcePack.fileSize,
        sha1Hash: resourcePack.sha1Hash,
        downloadUrl: resourcePack.downloadUrl,
        downloadCount: resourcePack.downloadCount
      });

    } catch (error: any) {
      console.error('Upload error:', error);
      res.status(500).json({ 
        message: error.message || 'Upload failed',
        error: error.message 
      });
    }
  });

  app.get("/api/resource-packs/:id", async (req, res) => {
    try {
      const resourcePack = await storage.getResourcePack(req.params.id);
      if (!resourcePack) {
        return res.status(404).json({ message: 'Resource pack not found' });
      }
      res.json(resourcePack);
    } catch (error) {
      console.error('Get resource pack error:', error);
      res.status(500).json({ message: 'Failed to get resource pack' });
    }
  });

  app.post("/api/resource-packs/:id/download", async (req, res) => {
    try {
      await storage.incrementDownloadCount(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error('Increment download error:', error);
      res.status(500).json({ message: 'Failed to increment download count' });
    }
  });

  app.get("/api/user/:userId/resource-packs", async (req, res) => {
    try {
      const resourcePacks = await storage.getResourcePacksByUser(req.params.userId);
      res.json(resourcePacks);
    } catch (error) {
      console.error('Get user packs error:', error);
      res.status(500).json({ message: 'Failed to get resource packs' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

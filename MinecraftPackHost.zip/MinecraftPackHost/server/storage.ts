import { type User, type InsertUser, type ResourcePack, type InsertResourcePack } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  
  getResourcePack(id: string): Promise<ResourcePack | undefined>;
  getResourcePacksByUser(userId: string): Promise<ResourcePack[]>;
  createResourcePack(resourcePack: InsertResourcePack & { userId: string }): Promise<ResourcePack>;
  incrementDownloadCount(id: string): Promise<void>;
  getUserStats(userId: string): Promise<{ totalUploads: number; totalDownloads: number }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private resourcePacks: Map<string, ResourcePack>;

  constructor() {
    this.users = new Map();
    this.resourcePacks = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      accessToken: null,
      refreshToken: null,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getResourcePack(id: string): Promise<ResourcePack | undefined> {
    return this.resourcePacks.get(id);
  }

  async getResourcePacksByUser(userId: string): Promise<ResourcePack[]> {
    return Array.from(this.resourcePacks.values()).filter(pack => pack.userId === userId);
  }

  async createResourcePack(data: InsertResourcePack & { userId: string }): Promise<ResourcePack> {
    const id = randomUUID();
    const resourcePack: ResourcePack = {
      ...data,
      id,
      downloadCount: 0,
      isPublic: true,
      createdAt: new Date()
    };
    this.resourcePacks.set(id, resourcePack);
    return resourcePack;
  }

  async incrementDownloadCount(id: string): Promise<void> {
    const pack = this.resourcePacks.get(id);
    if (pack) {
      pack.downloadCount = (pack.downloadCount || 0) + 1;
      this.resourcePacks.set(id, pack);
    }
  }

  async getUserStats(userId: string): Promise<{ totalUploads: number; totalDownloads: number }> {
    const userPacks = await this.getResourcePacksByUser(userId);
    const totalUploads = userPacks.length;
    const totalDownloads = userPacks.reduce((sum, pack) => sum + (pack.downloadCount || 0), 0);
    return { totalUploads, totalDownloads };
  }
}

export const storage = new MemStorage();

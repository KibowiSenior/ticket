import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  googleDriveId: text("google_drive_id"),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const resourcePacks = pgTable("resource_packs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  fileName: text("file_name").notNull(),
  originalName: text("original_name").notNull(),
  fileSize: integer("file_size").notNull(),
  sha1Hash: text("sha1_hash").notNull(),
  driveFileId: text("drive_file_id").notNull(),
  downloadUrl: text("download_url").notNull(),
  downloadCount: integer("download_count").default(0),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  name: true,
  googleDriveId: true,
});

export const insertResourcePackSchema = createInsertSchema(resourcePacks).pick({
  fileName: true,
  originalName: true,
  fileSize: true,
  sha1Hash: true,
  driveFileId: true,
  downloadUrl: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertResourcePack = z.infer<typeof insertResourcePackSchema>;
export type ResourcePack = typeof resourcePacks.$inferSelect;

import { Server, Gamepad2, Lightbulb } from "lucide-react";

export default function InstallationGuide() {
  return (
    <section id="guide" className="py-16 bg-muted/30">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground mb-4">How to Apply Resource Packs</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Follow these simple steps to add your resource pack to your Minecraft server or client.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="minecraft-card p-8 bg-card" data-testid="guide-server">
            <div className="flex items-center space-x-4 mb-6">
              <div className="minecraft-block w-12 h-12 rounded-lg flex items-center justify-center">
                <Server className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold">For Minecraft Servers</h3>
            </div>
            <ol className="space-y-4 text-sm">
              <li className="flex space-x-3">
                <span className="minecraft-block w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold">1</span>
                <div>
                  <p className="font-medium">Copy the download URL</p>
                  <p className="text-muted-foreground">Get the URL from your uploaded resource pack above</p>
                </div>
              </li>
              <li className="flex space-x-3">
                <span className="minecraft-block w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold">2</span>
                <div>
                  <p className="font-medium">Edit server.properties</p>
                  <p className="text-muted-foreground">Add the URL to your server configuration file</p>
                </div>
              </li>
              <li className="flex space-x-3">
                <span className="minecraft-block w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold">3</span>
                <div>
                  <p className="font-medium">Add the properties</p>
                  <div className="bg-muted p-3 rounded mt-2 font-mono text-xs">
                    resource-pack=https://your-download-url<br/>
                    resource-pack-sha1=your-sha1-hash<br/>
                    require-resource-pack=true
                  </div>
                </div>
              </li>
              <li className="flex space-x-3">
                <span className="minecraft-block w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold">4</span>
                <div>
                  <p className="font-medium">Restart your server</p>
                  <p className="text-muted-foreground">Players will be prompted to download the pack when they join</p>
                </div>
              </li>
            </ol>
          </div>

          <div className="minecraft-card p-8 bg-card" data-testid="guide-client">
            <div className="flex items-center space-x-4 mb-6">
              <div className="minecraft-block w-12 h-12 rounded-lg flex items-center justify-center">
                <Gamepad2 className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold">For Minecraft Client</h3>
            </div>
            <ol className="space-y-4 text-sm">
              <li className="flex space-x-3">
                <span className="minecraft-block w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold">1</span>
                <div>
                  <p className="font-medium">Download the resource pack</p>
                  <p className="text-muted-foreground">Click the download URL to save the .zip file</p>
                </div>
              </li>
              <li className="flex space-x-3">
                <span className="minecraft-block w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold">2</span>
                <div>
                  <p className="font-medium">Open Minecraft</p>
                  <p className="text-muted-foreground">Launch your Minecraft client</p>
                </div>
              </li>
              <li className="flex space-x-3">
                <span className="minecraft-block w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold">3</span>
                <div>
                  <p className="font-medium">Go to Options → Resource Packs</p>
                  <p className="text-muted-foreground">Navigate to the resource packs menu</p>
                </div>
              </li>
              <li className="flex space-x-3">
                <span className="minecraft-block w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold">4</span>
                <div>
                  <p className="font-medium">Click "Open Pack Folder"</p>
                  <p className="text-muted-foreground">Move your downloaded .zip file into this folder</p>
                </div>
              </li>
              <li className="flex space-x-3">
                <span className="minecraft-block w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold">5</span>
                <div>
                  <p className="font-medium">Activate the pack</p>
                  <p className="text-muted-foreground">Select your pack and move it to "Selected Resource Packs"</p>
                </div>
              </li>
            </ol>
          </div>
        </div>

        <div className="minecraft-card p-6 bg-card mt-8" data-testid="guide-tips">
          <div className="flex items-center space-x-3 mb-4">
            <Lightbulb className="h-5 w-5 text-primary" />
            <h4 className="font-semibold">Pro Tips</h4>
          </div>
          <ul className="text-sm text-muted-foreground space-y-2">
            <li>• Always include the SHA-1 hash in your server.properties for integrity verification</li>
            <li>• Set <code className="bg-muted px-1 rounded">require-resource-pack=true</code> to enforce resource pack usage</li>
            <li>• Test your resource pack on different Minecraft versions for compatibility</li>
            <li>• Consider pack.png and pack.mcmeta files for better presentation</li>
          </ul>
        </div>
      </div>
    </section>
  );
}

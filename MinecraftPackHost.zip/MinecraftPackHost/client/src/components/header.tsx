import { Package, HardDrive, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";

export default function Header() {
  const { user, isAuthenticated, login } = useAuth();

  const handleLogin = async () => {
    try {
      await login();
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  return (
    <header className="border-b border-border bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="minecraft-block w-8 h-8 rounded flex items-center justify-center">
              <Package className="h-5 w-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-primary">MCPacks</h1>
          </div>
          <nav className="hidden md:flex space-x-8">
            <a 
              href="#home" 
              className="text-muted-foreground hover:text-foreground transition-colors"
              data-testid="nav-home"
            >
              Home
            </a>
            <a 
              href="#upload" 
              className="text-muted-foreground hover:text-foreground transition-colors"
              data-testid="nav-upload"
            >
              Upload
            </a>
            <a 
              href="#guide" 
              className="text-muted-foreground hover:text-foreground transition-colors"
              data-testid="nav-guide"
            >
              Installation Guide
            </a>
          </nav>
          <div className="flex items-center space-x-4">
            <Button
              onClick={handleLogin}
              className="minecraft-block text-white px-4 py-2 rounded-md hover:opacity-90 transition-opacity"
              data-testid="button-connect-drive"
            >
              {isAuthenticated ? (
                <>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  <span>Connected</span>
                </>
              ) : (
                <>
                  <HardDrive className="h-4 w-4 mr-2" />
                  <span>Connect Google Drive</span>
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}

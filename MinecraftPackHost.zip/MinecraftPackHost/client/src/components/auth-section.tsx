import { HardDrive, CheckCircle, LogOut, Folder, Upload, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";

export default function AuthSection() {
  const { user, isAuthenticated, login, logout } = useAuth();

  const { data: stats } = useQuery({
    queryKey: ['/api/user', user?.id, 'stats'],
    enabled: !!user?.id,
  });

  const handleLogin = async () => {
    try {
      await login();
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  if (!isAuthenticated || !user) {
    return (
      <section className="py-8 bg-muted/30" id="authSection">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="minecraft-card p-8 bg-card text-center" data-testid="auth-not-connected">
            <div className="minecraft-block w-16 h-16 rounded-lg flex items-center justify-center mx-auto mb-6">
              <HardDrive className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold mb-4">Connect Your Google Drive</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              To upload resource packs, you need to authenticate with your Google Drive. Your files will be stored in your personal Drive account, 
              and you'll maintain full control over them.
            </p>
            <Button
              onClick={handleLogin}
              className="minecraft-block text-white px-8 py-3 rounded-lg hover:opacity-90 transition-opacity"
              data-testid="button-authenticate-drive"
            >
              <HardDrive className="h-5 w-5 mr-3" />
              <span className="font-medium">Authenticate with Google Drive</span>
            </Button>
            <p className="text-sm text-muted-foreground mt-4">
              We only request permission to create and manage files in a dedicated MCPacks folder.
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-8 bg-muted/30" id="authSection">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="minecraft-card p-8 bg-card" data-testid="auth-connected">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <div className="minecraft-block w-12 h-12 rounded-lg flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Google Drive Connected</h3>
                <p className="text-muted-foreground" data-testid="text-user-email">{user.email}</p>
              </div>
            </div>
            <Button
              variant="ghost"
              onClick={logout}
              className="text-muted-foreground hover:text-foreground transition-colors"
              data-testid="button-disconnect"
            >
              <LogOut className="h-4 w-4 mr-2" />
              <span>Disconnect</span>
            </Button>
          </div>
          <div className="grid md:grid-cols-3 gap-4 text-sm">
            <div className="bg-muted/50 p-4 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Folder className="h-4 w-4 text-primary" />
                <span className="font-medium">Storage Location</span>
              </div>
              <p className="text-muted-foreground">MCPacks folder in your Drive</p>
            </div>
            <div className="bg-muted/50 p-4 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Upload className="h-4 w-4 text-primary" />
                <span className="font-medium">Files Uploaded</span>
              </div>
              <p className="text-muted-foreground" data-testid="text-total-uploads">
                {stats?.totalUploads || 0} resource packs
              </p>
            </div>
            <div className="bg-muted/50 p-4 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Download className="h-4 w-4 text-primary" />
                <span className="font-medium">Total Downloads</span>
              </div>
              <p className="text-muted-foreground" data-testid="text-total-downloads">
                {stats?.totalDownloads || 0} downloads
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import { useEffect } from 'react';
import { useLocation } from 'wouter';

export default function OAuthCallback() {
  const [location] = useLocation();

  useEffect(() => {
    const handleCallback = async () => {
      try {
        // Get the authorization code from URL params
        const urlParams = new URLSearchParams(window.location.search);
        const code = urlParams.get('code');
        const error = urlParams.get('error');

        if (error) {
          // Send error to parent window
          if (window.opener) {
            window.opener.postMessage({
              type: 'OAUTH_ERROR',
              error: error
            }, window.location.origin);
          }
          return;
        }

        if (!code) {
          throw new Error('No authorization code received');
        }

        // Exchange code for tokens
        const response = await fetch('/api/auth/google/callback', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ code }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Authentication failed');
        }

        const data = await response.json();

        // Send success message to parent window
        if (window.opener) {
          window.opener.postMessage({
            type: 'OAUTH_SUCCESS',
            user: data.user,
            tokens: data.tokens
          }, window.location.origin);
        }

      } catch (error: any) {
        console.error('OAuth callback error:', error);
        
        // Send error to parent window
        if (window.opener) {
          window.opener.postMessage({
            type: 'OAUTH_ERROR',
            error: error.message || 'Authentication failed'
          }, window.location.origin);
        }
      }
    };

    handleCallback();
  }, [location]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center">
        <div className="minecraft-block w-16 h-16 rounded-lg flex items-center justify-center mx-auto mb-4">
          <div className="animate-spin h-8 w-8 border-4 border-white border-t-transparent rounded-full"></div>
        </div>
        <h2 className="text-xl font-semibold mb-2">Connecting to Google Drive</h2>
        <p className="text-muted-foreground">Please wait while we complete the authentication...</p>
      </div>
    </div>
  );
}

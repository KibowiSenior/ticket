import { Package, Github, Twitter } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-card border-t border-border py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center space-x-4 mb-4">
              <div className="minecraft-block w-8 h-8 rounded flex items-center justify-center">
                <Package className="h-5 w-5 text-white" />
              </div>
              <h3 className="text-xl font-bold text-primary">MCPacks</h3>
            </div>
            <p className="text-muted-foreground mb-4 max-w-md">
              Free Minecraft resource pack hosting using your own Google Drive storage. 
              Secure, fast, and completely under your control.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="link-github"
              >
                <Github className="h-5 w-5" />
              </a>
              <a 
                href="#" 
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="link-twitter"
              >
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Features</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-foreground transition-colors">Google Drive Integration</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Download Tracking</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">SHA-1 Verification</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Installation Guide</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-foreground transition-colors">Documentation</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">FAQ</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Contact</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Report Issue</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-muted-foreground">
            © 2024 MCPacks. Made with ❤️ for the Minecraft community.
          </p>
          <p className="text-sm text-muted-foreground mt-4 md:mt-0">
            Powered by <a 
              href="https://cloudnord.net/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary hover:underline font-medium"
              data-testid="link-cloudnord"
            >
              CloudNord
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}

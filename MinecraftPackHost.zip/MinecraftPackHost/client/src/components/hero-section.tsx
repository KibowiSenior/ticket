import { ShieldCheck, Zap, TrendingUp } from "lucide-react";

export default function HeroSection() {
  return (
    <section id="home" className="py-16 bg-gradient-to-br from-muted/30 to-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Host Minecraft Resource Packs
            <span className="text-primary"> for Free</span>
          </h2>
          <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
            Upload your resource packs to your own Google Drive and get instant download links for your Minecraft server. 
            Secure, fast, and completely free.
          </p>
          
          {/* CloudNord Promotional Section */}
          <div 
            onClick={() => window.open('https://cloudnord.net/', '_blank')}
            className="bg-gradient-to-r from-slate-800 to-gray-800 dark:from-slate-700 dark:to-gray-700 rounded-xl p-6 mb-8 border-2 border-slate-600/50 dark:border-slate-500/50 cursor-pointer transition-all duration-300 hover:shadow-xl hover:shadow-slate-500/25 hover:scale-[1.02] relative overflow-hidden group"
          >
            {/* Animated border highlight */}
            <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="absolute inset-0 rounded-xl border-2 border-blue-400 dark:border-blue-300 animate-pulse"></div>
              <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-blue-400/20 to-cyan-400/20 dark:from-blue-300/20 dark:to-cyan-300/20"></div>
            </div>
            
            <div className="relative flex items-center justify-center gap-4 flex-wrap">
              <span className="text-lg font-medium text-white group-hover:text-blue-100 transition-colors">
                Start your Minecraft server with
              </span>
              <img 
                src="https://cloudnord.net/templates/rosa/img/cn-light.png" 
                alt="CloudNord" 
                className="h-8 opacity-90 group-hover:opacity-100 transition-all duration-300 group-hover:scale-110 filter brightness-110"
              />
            </div>
          </div>
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            <div className="minecraft-card p-6 bg-card" data-testid="feature-security">
              <div className="minecraft-block w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4">
                <ShieldCheck className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Your Drive, Your Files</h3>
              <p className="text-muted-foreground">Files are stored in your personal Google Drive, giving you complete control.</p>
            </div>
            <div className="minecraft-card p-6 bg-card" data-testid="feature-speed">
              <div className="minecraft-block w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Zap className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Instant Download Links</h3>
              <p className="text-muted-foreground">Get public download URLs immediately after upload with SHA-1 verification.</p>
            </div>
            <div className="minecraft-card p-6 bg-card" data-testid="feature-tracking">
              <div className="minecraft-block w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Download Tracking</h3>
              <p className="text-muted-foreground">Monitor how many times your resource pack has been downloaded.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

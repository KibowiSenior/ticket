import { useState, useCallback } from "react";
import { UploadCloud, Upload, CheckCircle, Copy, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface UploadResult {
  id: string;
  fileName: string;
  fileSize: number;
  sha1Hash: string;
  downloadUrl: string;
  downloadCount: number;
}

export default function UploadSection() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadResult, setUploadResult] = useState<UploadResult | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: `${label} copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Could not copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const validateFile = (file: File): string | null => {
    const maxSize = 95 * 1024 * 1024; // 95MB
    const allowedTypes = ['.zip', '.mcpack'];
    const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));

    if (!allowedTypes.includes(fileExtension)) {
      return 'Only .zip and .mcpack files are allowed';
    }

    if (file.size > maxSize) {
      return 'File size must be less than 95MB';
    }

    return null;
  };

  const uploadFile = async (file: File) => {
    if (!isAuthenticated || !user) {
      toast({
        title: "Authentication required",
        description: "Please connect your Google Drive first",
        variant: "destructive",
      });
      return;
    }

    const validation = validateFile(file);
    if (validation) {
      toast({
        title: "Invalid file",
        description: validation,
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('userId', user.id);
      formData.append('accessToken', user.accessToken!);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Upload failed');
      }

      const result = await response.json();
      setUploadResult(result);
      
      // Invalidate user stats to refresh
      queryClient.invalidateQueries({ queryKey: ['/api/user', user.id, 'stats'] });

      toast({
        title: "Upload successful!",
        description: "Your resource pack is now available for download",
      });

    } catch (error: any) {
      toast({
        title: "Upload failed",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      setSelectedFile(null);
    }
  };

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    uploadFile(file);
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, []);

  const resetUpload = () => {
    setUploadResult(null);
    setUploadProgress(0);
    setSelectedFile(null);
  };

  if (!isAuthenticated) {
    return (
      <section id="upload" className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Upload Resource Pack</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Please connect your Google Drive first to upload resource packs.
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="upload" className="py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground mb-4">Upload Resource Pack</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Drop your Minecraft resource pack here or click to browse. Maximum file size: 95MB.
          </p>
        </div>

        {!uploadResult && !isUploading && (
          <div className="minecraft-card p-8 bg-card mb-8" data-testid="upload-area">
            <div
              className={`upload-zone p-12 text-center cursor-pointer ${isDragging ? 'border-primary/70 bg-primary/5' : ''}`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => document.getElementById('fileInput')?.click()}
              data-testid="drop-zone"
            >
              <div className="minecraft-block w-20 h-20 rounded-lg flex items-center justify-center mx-auto mb-6">
                <UploadCloud className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Drop your resource pack here</h3>
              <p className="text-muted-foreground mb-6">or click to browse files</p>
              <input
                type="file"
                id="fileInput"
                className="hidden"
                accept=".zip,.mcpack"
                onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
                data-testid="input-file"
              />
              <Button className="minecraft-block text-white px-6 py-3 rounded-lg hover:opacity-90 transition-opacity">
                Choose File
              </Button>
              <p className="text-sm text-muted-foreground mt-4">
                Supported formats: .zip, .mcpack • Maximum size: 95MB
              </p>
            </div>
          </div>
        )}

        {isUploading && (
          <div className="minecraft-card p-8 bg-card mb-8" data-testid="upload-progress">
            <div className="flex items-center space-x-4 mb-4">
              <div className="minecraft-block w-10 h-10 rounded flex items-center justify-center">
                <Upload className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-medium" data-testid="text-upload-filename">
                  {selectedFile?.name || 'resource-pack.zip'}
                </p>
                <p className="text-sm text-muted-foreground" data-testid="text-upload-filesize">
                  {selectedFile ? formatFileSize(selectedFile.size) : '0 MB'}
                </p>
              </div>
            </div>
            <Progress value={uploadProgress} className="mb-4" />
            <p className="text-sm text-muted-foreground text-center" data-testid="text-upload-status">
              Uploading to your Google Drive...
            </p>
          </div>
        )}

        {uploadResult && (
          <div className="success-animation" data-testid="upload-success">
            <div className="minecraft-card p-8 bg-card border-primary">
              <div className="flex items-center space-x-4 mb-6">
                <div className="minecraft-block w-12 h-12 rounded-lg flex items-center justify-center">
                  <CheckCircle className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-primary">Upload Successful!</h3>
                  <p className="text-muted-foreground">Your resource pack is now available for download</p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Download URL</label>
                  <div className="flex">
                    <Input
                      type="text"
                      readOnly
                      value={uploadResult.downloadUrl}
                      className="flex-1 rounded-r-none bg-muted"
                      data-testid="input-download-url"
                    />
                    <Button
                      onClick={() => copyToClipboard(uploadResult.downloadUrl, 'Download URL')}
                      className="copy-button bg-primary text-white rounded-l-none hover:bg-primary/90"
                      data-testid="button-copy-url"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">SHA-1 Hash</label>
                  <div className="flex">
                    <Input
                      type="text"
                      readOnly
                      value={uploadResult.sha1Hash}
                      className="flex-1 rounded-r-none bg-muted font-mono"
                      data-testid="input-sha1-hash"
                    />
                    <Button
                      onClick={() => copyToClipboard(uploadResult.sha1Hash, 'SHA-1 Hash')}
                      className="copy-button bg-primary text-white rounded-l-none hover:bg-primary/90"
                      data-testid="button-copy-hash"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 bg-muted/50 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Info className="h-4 w-4 text-primary" />
                  <span className="font-medium">File Information</span>
                </div>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">File Name:</span>
                    <p className="font-medium" data-testid="text-result-filename">{uploadResult.fileName}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">File Size:</span>
                    <p className="font-medium" data-testid="text-result-filesize">{formatFileSize(uploadResult.fileSize)}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Downloads:</span>
                    <p className="font-medium" data-testid="text-result-downloads">{uploadResult.downloadCount}</p>
                  </div>
                </div>
              </div>

              <div className="flex justify-center mt-6">
                <Button
                  onClick={resetUpload}
                  className="minecraft-block text-white px-6 py-3 rounded-lg hover:opacity-90 transition-opacity"
                  data-testid="button-upload-another"
                >
                  Upload Another Pack
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

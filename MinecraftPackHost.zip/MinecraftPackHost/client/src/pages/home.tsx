import Header from "@/components/header";
import HeroSection from "@/components/hero-section";
import AuthSection from "@/components/auth-section";
import UploadSection from "@/components/upload-section";
import InstallationGuide from "@/components/installation-guide";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <HeroSection />
      <AuthSection />
      <UploadSection />
      <InstallationGuide />
      <Footer />
    </div>
  );
}

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '@shared/schema';

interface AuthContextType {
  user: (User & { accessToken?: string; refreshToken?: string }) | null;
  isAuthenticated: boolean;
  login: () => Promise<void>;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<(User & { accessToken?: string; refreshToken?: string }) | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for stored auth data on mount
    const storedUser = localStorage.getItem('mcpacks_user');
    const storedTokens = localStorage.getItem('mcpacks_tokens');
    
    if (storedUser && storedTokens) {
      try {
        const userData = JSON.parse(storedUser);
        const tokenData = JSON.parse(storedTokens);
        setUser({ 
          ...userData, 
          accessToken: tokenData.access_token,
          refreshToken: tokenData.refresh_token 
        });
      } catch (error) {
        console.error('Failed to parse stored auth data:', error);
        localStorage.removeItem('mcpacks_user');
        localStorage.removeItem('mcpacks_tokens');
      }
    }
    setLoading(false);
  }, []);

  const login = async () => {
    try {
      setLoading(true);
      
      // Get Google OAuth URL from backend
      const response = await fetch('/api/auth/google');
      if (!response.ok) {
        throw new Error('Failed to get authentication URL');
      }
      
      const { url } = await response.json();
      
      // Open popup window for OAuth
      const popup = window.open(
        url, 
        'googleAuth', 
        'width=500,height=600,left=' + 
        (window.screen.width / 2 - 250) + 
        ',top=' + 
        (window.screen.height / 2 - 300)
      );
      
      if (!popup) {
        throw new Error('Failed to open authentication popup. Please allow popups for this site.');
      }
      
      return new Promise<void>((resolve, reject) => {
        const messageHandler = (event: MessageEvent) => {
          // Check if message is from our OAuth popup
          if (event.origin !== window.location.origin) {
            return;
          }

          if (event.data.type === 'OAUTH_SUCCESS') {
            const { user: userData, tokens } = event.data;
            
            const userWithTokens = {
              ...userData,
              accessToken: tokens.access_token,
              refreshToken: tokens.refresh_token
            };
            
            setUser(userWithTokens);
            localStorage.setItem('mcpacks_user', JSON.stringify(userData));
            localStorage.setItem('mcpacks_tokens', JSON.stringify(tokens));
            
            window.removeEventListener('message', messageHandler);
            popup.close();
            setLoading(false);
            resolve();
          } else if (event.data.type === 'OAUTH_ERROR') {
            window.removeEventListener('message', messageHandler);
            popup.close();
            setLoading(false);
            reject(new Error(event.data.error || 'Authentication failed'));
          }
        };

        window.addEventListener('message', messageHandler);

        // Fallback: poll for popup closure
        const pollForClosure = setInterval(() => {
          if (popup.closed) {
            clearInterval(pollForClosure);
            window.removeEventListener('message', messageHandler);
            setLoading(false);
            reject(new Error('Authentication cancelled'));
          }
        }, 1000);

        // Timeout after 5 minutes
        setTimeout(() => {
          clearInterval(pollForClosure);
          window.removeEventListener('message', messageHandler);
          if (!popup.closed) {
            popup.close();
          }
          setLoading(false);
          reject(new Error('Authentication timeout'));
        }, 300000);
      });
    } catch (error) {
      setLoading(false);
      console.error('Login error:', error);
      throw error;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('mcpacks_user');
    localStorage.removeItem('mcpacks_tokens');
  };

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      login,
      logout,
      loading
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

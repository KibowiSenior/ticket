# Overview

MCPacks is a Minecraft resource pack hosting platform that allows users to upload their resource packs to their own Google Drive storage and get instant download links. The application provides a free, secure solution for hosting Minecraft resource packs without requiring dedicated file storage infrastructure. Users maintain complete control over their files while getting public download URLs with SHA-1 verification and download tracking capabilities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built using **React 18** with **TypeScript** and follows a component-based architecture:

- **Routing**: Uses Wouter for client-side routing with a single-page application structure
- **State Management**: React Query (TanStack Query) for server state management with local state handled by React hooks
- **UI Framework**: Shadcn/ui components built on Radix UI primitives for accessibility and customization
- **Styling**: Tailwind CSS with custom CSS variables for theming and Minecraft-inspired design elements
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

## Backend Architecture
The backend follows a **REST API** pattern built with **Express.js**:

- **Framework**: Express.js with TypeScript for type safety
- **File Upload**: Multer middleware for handling multipart form data with 95MB file size limits
- **File Validation**: Restricts uploads to `.zip` and `.mcpack` file extensions
- **Logging**: Custom request/response logging middleware for API monitoring
- **Error Handling**: Centralized error handling middleware with structured error responses

## Data Storage Solutions
The application uses a **dual storage approach**:

- **Database**: PostgreSQL with Drizzle ORM for relational data (users, resource pack metadata)
  - Users table: Stores user profiles and OAuth tokens
  - Resource packs table: Stores file metadata, download counts, and Drive file references
- **File Storage**: Google Drive API for actual file storage
  - Files stored in user's personal Google Drive account
  - Organized in dedicated MCPacks folder structure
- **In-Memory Fallback**: MemStorage class provides development/testing storage without database dependency

## Authentication and Authorization
**Google OAuth 2.0** integration for secure authentication:

- **OAuth Flow**: Standard authorization code flow with PKCE
- **Token Management**: Access and refresh tokens stored securely with automatic refresh handling
- **Drive Permissions**: Limited scope requesting only file creation and management permissions
- **Session Handling**: JWT-based authentication with secure token storage
- **Popup-based Auth**: Client-side popup window for seamless OAuth flow

## External Service Integrations

### Google Drive API
- **File Management**: Upload, organize, and manage resource pack files
- **Public Sharing**: Generate public download links for hosted files
- **Folder Organization**: Automatic creation and management of MCPacks folder structure
- **File Metadata**: Extract and store file information including size and MIME types

### Google Cloud Services
- **OAuth 2.0**: User authentication and authorization
- **Drive API v3**: File storage and management operations
- **API Security**: Proper credential management and rate limiting

## Build and Development Tools
- **Vite**: Fast development server and build tool with HMR support
- **ESBuild**: Production bundling for server-side code
- **TypeScript**: End-to-end type safety across client, server, and shared code
- **Drizzle Kit**: Database schema management and migrations
- **Path Aliases**: Organized import structure with @ and @shared aliases for clean code organization

## Security Considerations
- **File Validation**: Strict file type checking and size limits
- **SHA-1 Verification**: File integrity checking with hash generation
- **CORS Configuration**: Proper cross-origin request handling
- **Environment Variables**: Secure configuration management for API keys and database URLs
- **Input Sanitization**: Zod schema validation for all user inputs